"""
A module containing funciton for creation and update of various gui elements.
"""

# importing libraries
import numpy as np

import tkinter as tk
from tkinter import ttk
from tkinter import font
import sv_ttk
import pywinstyles, sys

import regex as re
import os


def load_filelist(folder):
    """
    Create a sorted list of image file paths from a folder, with extensions '.png', '.tif', 
    and '.tiff'.

    Parameters:
        folder (str): Path to the directory.

    Returns:
        list of str: Sorted list of full file paths to image files in folder.
    """
    image_files = [                                           # Creates a list of image file paths
        os.path.join(folder, f) for f in os.listdir(folder)   # in the selected folder
        if f.lower().endswith(('.png','.tif', '.tiff')) ]
    image_files.sort()
    return image_files   

def shorten_folder_path(folder):
    """
    Shorten folder path for display in gui.

    Parameters:
        folder (str): folder path

    Returns:
        str: shortened folder path
    """
    if len(folder)>70:
        return "..."+folder[-67:]
    else:
        return folder

def change_state_of_elements(disable=None, enable=None, set_false=None, set_true=None):
    """
    Change widget states and BooleanVar values in bulk. This funciton helps in disabling or 
    enabling multiple tkinter widgets at once.

    Parameters:
        disable (iterable of tkinter Widget, optional): Widgets to set to disabled state. 
        enable (iterable of tkinter Widget, optional): Widgets to set to normal state. 
        set_false (iterable of tkinter.BooleanVar, optional): BooleanVar objects to set to False. 
        set_true (iterable of tkinter.BooleanVar, optional): BooleanVar objects to set to True.

    Returns:
        None 
    """
    if set_false is not None:
        for var in set_false:
            var.set(False)          
    if set_true is not None:
        for var in set_true:
            var.set(True)         
    if disable is not None:
        for element in disable:
            element.config(state="disabled")
    if enable is not None:
        for element in enable:
            element.config(state="normal")  

def create_cb(parent,to_function, text="",side=tk.LEFT,justify="left",padx=(0,0)):
    """
    Create and pack a Checkbutton tied to a BooleanVar.

    Parameters:
        parent (tkinter.Widget): Parent frame to place the Checkbutton in.
        to_function (callable): Function to call when the checkbutton is toggled.
        text (str, optional): For setting label text (default="") of the checkbutton.
        side (str, optional): For packing (default=tk.LEFT) the checkbutton.
        justify (str, optional): For setting label text justification (default="left") of the checkbutton.
        padx (tuple or int, optional): x Padding (default: 0)

    Returns:
        tuple (tk.Checkbutton, tk.BooleanVar): The created widget and its BooleanVar.
    """
    var = tk.BooleanVar()
    checkbox = ttk.Checkbutton(parent, text=text, variable=var, command=to_function) #justify=justify
    checkbox.pack(side=side,padx=padx)
    return checkbox, var

def create_tb(parent, function_binding=lambda x: None,bound_how=None, init_txt="", width=5,padx=(0,0),side=tk.LEFT):
    """
    Create an textbox/ Entry widget with an associated StringVar and pack it.

    Parameters:
         parent (tkinter.Widget): Parent frame to place the textbox in 
         function_binding (callable): Function to call when the user interacts with the textbox
         bound_how (str, optional): If provided, the event string to bind (e.g. "<Return>", "<KeyRelease>").
                                    If None, no binding is created.
         init_txt (str, optional): Initial text to add in the widget.
         width (int, optional):  Width (default: 5) of the widget.
         padx (tuple or int, optional): x padding (default: 0) of the widget.
         side (str, optional): packing (default: tk.LEFT) of the widget.

    Returns:
        tuple (ttk.Entry, ttk.StringVar): The created Entry widget and its backing StringVar.
    """
    var = tk.StringVar()
    var.set(init_txt)
    textbox = ttk.Entry(parent,textvariable=var, width=width )
    textbox.pack(side=side,  padx=padx)
    if bound_how:
        textbox.bind(bound_how, function_binding)
    return textbox, var

def create_toplevel_container(parent, fill=tk.BOTH, expand=True, side=tk.TOP, padx=5, pady=5, **pack_kwargs):
    """
    Create a top-level container frame and pack it to fill space.

    Parameters:
        parent (tkinter.Widget): Parent container.
        fill (str, optional): Fill (default: tk.BOTH) argument for placing the widget.
        expand (bool, optional): Expand (default: True) argument for placing the widget.
        side (str, optional): Side (default: tk.TOP) argument for placing the widget.
            
    Returns:
        tk.Frame: The created frame.
    """
    top_frame = ttk.Frame(parent); 
    top_frame.pack(fill=fill, expand=expand, side=side, padx=padx, pady=pady, **pack_kwargs)
    return top_frame

def create_frame(parent,fill=tk.X,padx=5, pady=5, **pack_kwargs):
    """
    Create a frame to place labels, textboxes and checkbuttons allowing user control

    Parameters:
         parent (tkinter.Widget): Parent container.
         fill (str, optional): Fill (default: tk.X)
         padx (int, optional): Horizontal padding (default: 5)
         pady (int, optional): Vertical padding (default: 5).

    Returns:
        tk.Frame: The created frame.
    """
    controls_frame = ttk.Frame(parent,  borderwidth=1, relief="flat");
    controls_frame.pack(fill=fill, padx=padx, pady=pady, **pack_kwargs)
    return controls_frame

def create_bordered_frame(parent, border_color="#000000", border_width=2, **pack_kwargs):
    """
    Create a ttk.Frame with a subtle visible border using an outer tk.Frame.

    Parameters:
        parent: parent widget
        border_color: color of the border
        border_width: thickness of the border in pixels
        pack_kwargs: kwargs for outer frame packing

    Returns:
        ttk.Frame: inner_frame (the frame inside the border)
    """
    # Outer frame acts as the border
    outer_frame = tk.Frame(parent, bg=border_color)
    outer_frame.pack(**pack_kwargs)

    # Inner ttk.Frame with same background as parent
    inner_frame = ttk.Frame(outer_frame)
    inner_frame.pack(padx=border_width, pady=border_width, fill=tk.BOTH, expand=True)

    return inner_frame

def create_button(parent,text, to_function, side=tk.LEFT, padx=5, width=None):
    """
    Create and pack a Button widget.

    Parameters:
      parent (tkinter.Widget): Parent container.
      text (str): Button label text 
      to_function (callable): Function to call when the button is pressed 
      side (str, optional): packing (default: tk.LEFT), 
      padx (int, optional): x padding (default: 5) 
      width (int, optional): button width (default: None, i.e, auto size)

    Returns:
        tk.Button: the created Button widget.
    """
    button = ttk.Button(parent, text=text, command=to_function, style="Accent.TButton")
    if width:
        button.config(width=width)
    button.pack(side=side, padx=padx)
    return button

def create_label(parent,text="",textvariable=None,side=tk.LEFT, padx=5, anchor=tk.W):
    """
    Create and pack a Label widget.

    Parameters:
      parent (tkinter.Widget): Parent container.
      text (str, optional): Static text for the label (default: "").
      textvariable (tkinter.StringVar, optional): StringVar for dynamic label content.
      side (str, optional): Packing (default: tk.LEFT)
      padx (int, optional): x padding (default: 5)
      anchor (str, optional): Anchor (default: tk.W / west) for label      
                Note: If both `text` and `textvariable` are provided, tkinter will prioritize
                     textvariable for dynamic updates. You can pass None to use only static text.

    Returns:
         tkinter.Label: The created Label widget.
    """
    label = ttk.Label(parent, text=text, anchor=anchor, textvariable=textvariable)
    label.pack(side=side, padx=padx)
    return label

def create_canvas(parent, bg='#1C1C1C' ,  padx=0, pady=0, fill=tk.BOTH, expand=True):
    """
    Create a Canvas widget configured to fill available space.

    Parameters:
      parent (tkinter.Widget): Parent container.
      bg (str, optional): Background color for the canvas (default: '#1C1C1C').
      padx (int, optional): Horizontal padding (default: 0)
      pady (int, optional): Vertical padding (default: 0)
      fill (str, optional): Fill (default: tk.BOTH) option for packing the canvas.
      expand (bool, optional): expand (default: True) option for packing the canvas.

    Returns:
       tkinter.Canvas: The created Canvas widget.
    """
    canvas = tk.Canvas(parent, bg=bg)
    canvas.pack(fill=fill, expand=expand, padx=padx, pady=pady)
    return canvas

def create_slider(parent, to_function, from_=0, to=0, orient=tk.HORIZONTAL, side=tk.LEFT, fill=tk.X, padx=0, pady=0, expand=True):
    """
    Create and pack a ttk.Scale (slider) widget.

    Parameters:
      parent (tkinter.Widget): Parent frame.
      to_function (callable, optional): Function called  when user interacts with the slider.
                                            The callback function will receive a single string argument 
                                            representing the value of slider position.
      `from_` (number, optional): Lower bound for the slider (default: 0).
      to (number, optional): upper bound for the slider (default: 0).
      orient (str, optional): Orientation of the slider (default: tk.HORIZONTAL) 
      side (str, optional): packing side (default: tk.LEFT)
      fill (str, optional): packing fill (default: tk.X)
      expand (bool, optional): expand (default: True)
      padx (int, optional): x padding (default: 0)
      pady (int, optional): y padding (default: 0)

    Returns:
      ttk.Scale:  The created slider widget.
    """
    slider = ttk.Scale(parent, from_=from_, to=to, orient=orient, command=to_function)
    slider.pack(side=side, fill=fill, padx=padx, pady=pady, expand=expand)
    return slider

def update_slider_label(slider_label_var, current_index, image_files, blocking_var=None):
    """
    Update a slider label widget with the the current slider position in the follwoing format:
    current slider position/ total number of images

    Parameters:
      slider_label_var (tkinter.StringVar): Stringvar Variable connected to slider label. 
                                                updating this variable updates the slider label.
      current_index (int): Current image number being shown (0-based)
      image_files (sequence): Iterable of image file paths; used to determine total count.
      blocking_var (tkinter.BooleanVar, optional):
                       If provided and True, The slider label will be set to "0 / 0".
                       This is because in some part of the gui, when a certain checkbox is checked, 
                       user shouldnt see the slider value

    Returns:
      None: as `slider_label_var` is mutable
    """
    current_num = f"{current_index + 1}";total_num = f"{len(image_files)}"
    slider_label_var.set(" "*(len(total_num)-len(current_num))+current_num + "/" + total_num) 
    if blocking_var is not None:
        if (not image_files) or (blocking_var.get()):
            slider_label_var.set("0 / 0") 

def update_vars_from_tb_input(textbox=None, other_inputs=None, vars_to_update=None):
    """
    Parse and validate values coming from textboxes, and update variables according to textbox input.
    Parameters:
      textbox (string):  name of the gui textbox ('split' or 'straylight' or 'FOV'.)
      vars_to_update (tuple of variables): The variables that needs to be updated according to textbox input
      other_inputs (tuple of variables): Additional inputs required to correctly update variables
    
    Returns:
      tuple: tuple of the updated variables
    """
    if textbox=='split':
        split_position=vars_to_update
        (avg_bkg_image, split_pos_input)=other_inputs
        try:
            val = split_pos_input.get().strip()
            split_position = int(float(val))
            if split_position >= avg_bkg_image.shape[1]:
                split_position = avg_bkg_image.shape[1] - 1
            if split_position <3:
                split_position=3
        except Exception:
            pass
        return split_position
    
    if textbox=='straylight':
        straylit_thresh_tb_var=other_inputs
        (left_stray_min,left_stray_max,right_stray_min,right_stray_max)=vars_to_update
        try:
            string_list = straylit_thresh_tb_var.get().strip().split()
            int_list = [int(float(s)) for s in string_list]
            if len(int_list) == 4:
                (left_stray_min, left_stray_max, right_stray_min, right_stray_max) = int_list
        except Exception:
            pass
        return (left_stray_min, left_stray_max, right_stray_min, right_stray_max)

    if textbox=="FOV":
        eff_fov_thresh=vars_to_update
        fov_thresh_tb_var=other_inputs
        try:
            eff_fov_thresh = float(fov_thresh_tb_var.get().strip())
        except ValueError:
            pass
        return eff_fov_thresh
    
    if textbox=='liss_smooth':
        liss_smooth=vars_to_update
        (smoothing_tb_var, img)=other_inputs
        try:
            liss_smooth=float(smoothing_tb_var.get().strip())
            max_liss_smooth=min(img.shape[0], img.shape[1])//24
            if liss_smooth<0.0001:
                liss_smooth=0.0001
            if liss_smooth>max_liss_smooth:
                liss_smooth=max_liss_smooth
        except:
            pass
        return liss_smooth
    
def map_clicks_on_canvas_to_image_coordinate(canvas, canvas_image_id, canvas_image, original_image, canvas_coords_of_click):
    """
    Map a click on a tkinter Canvas to the corresponding pixel coordinate on the original image.

    Parameters:
      canvas (tkinter.Canvas): Canvas with the displayed image.
      canvas_image_id (int): The canvas object id (from canvas.create_image(...)) representing the image.
      canvas_image (tkinter.PhotoImage): The tk image object currently shown in the canvas 
                                            (a scaled version of the original image).
      original_image (numpy 2D array): The original image
      canvas_coords_of_click (tkinter.Event object): Event object representing the mouse click coordinates
                                                        relative to the canvas widget.

    Returns:
      (tuple of int): Represents the (x, y) pixel coordinates in the original image 
                           corresponding to the click.
    """
    offset= canvas.coords(canvas_image_id) #center pt of the canvas
    tkimagesize=(canvas_image.width(),canvas_image.height())
    tkimagescale=np.mean([original_image.shape[1]/tkimagesize[0], original_image.shape[0]/tkimagesize[1]])
    selected_pt= (int((canvas_coords_of_click.x-(offset[0]-tkimagesize[0]/2) )*tkimagescale),
                    int((canvas_coords_of_click.y-(offset[1]-tkimagesize[1]/2) )*tkimagescale) )
    if not ((selected_pt[0]<0) or (selected_pt[1]<0) or  # return coordinates only if click was inside image. 
            (selected_pt[0]>original_image.shape[1]) or 
            (selected_pt[1]>original_image.shape[0])):
        return selected_pt
    


def clear_window_content(parent):
    """ Clear any previous content/widget from this window"""
    for widget in parent.winfo_children():
        widget.destroy()

def apply_dark_theme_to_titlebar(root):
    """
    This is a codeblock provided in sun valley ttk theme documentation
    to turn the title bar of the created windows dark colored.
    """
    version = sys.getwindowsversion()

    if version.major == 10 and version.build >= 22000:
        # Set the title bar color to the background color on Windows 11 for better appearance
        pywinstyles.change_header_color(root, "#000000" if sv_ttk.get_theme() == "dark" else "#fafafa")
    elif version.major == 10:
        pywinstyles.apply_style(root, "dark" if sv_ttk.get_theme() == "dark" else "normal")

        # A hacky way to update the title bar's color on Windows 10 (it doesn't update instantly like on Windows 11)
        root.wm_attributes("-alpha", 0.99)
        root.wm_attributes("-alpha", 1)


def apply_fontstyle(root, fontfamily, fontsize):
    """
    This function applies font style to all tkinter and ttkinter widgets
    """
    default_font = font.Font(root=root, family=fontfamily, size=fontsize)

    style = ttk.Style(root)
    
    widget_types = ["TButton", "TLabel", "TEntry", "TCheckbutton", "TRadiobutton", "TMenubutton", "TNotebook", "TCombobox"]

    for wtype in widget_types:
        style.configure(wtype, font=default_font)

    default_font2 = font.nametofont("TkDefaultFont")
    default_font2.configure(family=fontfamily, size=fontsize)

    text_font = font.nametofont("TkTextFont")
    text_font.configure(family=fontfamily, size=fontsize)

    menu_font = font.nametofont("TkMenuFont")
    menu_font.configure(family=fontfamily, size=fontsize)