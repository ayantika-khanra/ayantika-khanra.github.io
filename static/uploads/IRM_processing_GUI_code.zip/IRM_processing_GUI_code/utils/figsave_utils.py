import matplotlib

from matplotlib.figure import Figure
from matplotlib.backends.backend_agg import FigureCanvasAgg as FigureCanvas
from concurrent.futures import ProcessPoolExecutor
import time
import numpy as np
import os

def save_plot(i):
    fig = Figure()
    canvas = FigureCanvas(fig)
    ax = fig.add_subplot(111)
    x=np.arange(0,10,0.01)
    ax.scatter(x,x)
    ax.plot(x,x*2)
    fig.savefig(f"trash/plot_{i}.png")

if __name__ == "__main__":  # important for Windows!
    start = time.time()
    with ProcessPoolExecutor(max_workers=8) as executor:
        executor.map(save_plot, range(500))
    end = time.time()
    print(f"Time taken: {end - start:.4f} seconds")
