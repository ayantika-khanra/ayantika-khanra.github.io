"""Module providing help message dialogs for different windows in the DW-IRM Tkinter application."""

import tkinter as tk

def show_help_imviewer_window():
    """Triggered by Help button in image viewer window (first window)"""
    help_text = (
    "In an 𝗗𝘂𝗮𝗹 𝘄𝗮𝘃𝗲𝗹𝗲𝗻𝘁𝗴𝗵 𝗜𝗻𝘁𝗲𝗿𝗳𝗲𝗿𝗲𝗻𝗰𝗲 𝗥𝗲𝗳𝗹𝗲𝗰𝘁𝗶𝗼𝗻 𝗠𝗶𝗰𝗿𝗼𝘀𝗰𝗼𝗽𝘆 (𝗗𝗪-𝗜𝗥𝗠) experiment, you capture two types of image sets with the 𝗢𝗽𝘁𝗼𝗦𝗽𝗹𝗶𝘁 instrument:\n\n"
    "𝟭. 𝗕𝗮𝗰𝗸𝗴𝗿𝗼𝘂𝗻𝗱 𝗜𝗺𝗮𝗴𝗲 𝘀𝗲𝗿𝗶𝗲𝘀:\n"
    "  ⚫ These are taken from regions of the sample where no object is present.\n"
    "  ⚫ They are used later to normalize intensity.\n"
    "  ⚫ Please capture around 25–50 images in a noise-free area.\n\n"
    "𝟮. 𝗜𝗥𝗠 𝗜𝗺𝗮𝗴𝗲 𝘀𝗲𝗿𝗶𝗲𝘀:\n"
    "  ⚫ These are the experimental interference microscopy images of an object, such as a membrane.\n"
    "  ⚫ Please capture a sequence of 300–1000 images, at a fixed time gap, using a camers.\n"
    "  ⚫ Image names should be sorted, image size should be consistent, and selected folders should have .png, .tiff or .tif files only.\n\n"
    "𝗡𝗼𝘁𝗲: In all DW-IRM images taken by OptoSplit, left side and right side image corresponds to interference pattern at two different wavelentghs. \n\n\n"
    "----------------------------\n"
    "𝗚𝘂𝗶𝗱𝗲 𝗳𝗼𝗿 𝘁𝗵𝗶𝘀 𝘄𝗶𝗻𝗱𝗼𝘄:\n"
    "----------------------------\n\n"
    "𝗧𝗼𝗽 𝗛𝗮𝗹𝗳:\n"
    "  ⚫ Click 'Load Background Folder' button, load your background image series.\n"
    "  ⚫ Use the slider to browse through images.\n"
    "  ⚫ Check 'Show Average of the Stack' to view the averaged image.\n\n"
    "𝗕𝗼𝘁𝘁𝗼𝗺 𝗛𝗮𝗹𝗳:\n"
    "  ⚫ Click 'Load IRM Folder' button, load the microscopy image series.\n"
    "  ⚫ Use the slider to scroll through the images.\n\n"
    "Once both folders are successfully loaded, the 'Next' button will be enabled. Click it.")
    tk.messagebox.showinfo("Help", help_text)


def show_help_analyze_window():
    """Triggered by Help button in Analyze window (Second window)"""
    help_text =("Currently, the images on the left and right halves of the frame are captured at two different wavelengths."
                "The goal of this window is to calculate quanitites needed for image registration and intensity normalization."
                "Finally, in the next windows, for each pixel, pair of interference intensities (normalized) will be calculated for the two wavelength.\n\n"
                "𝗙𝗼𝗿 𝗿𝗲𝗴𝗶𝘀𝘁𝗿𝗮𝘁𝗶𝗼𝗻, 𝘄𝗲 𝗻𝗲𝗲𝗱:\n"
                "  ⚫ Split line: the dividing line that separates the left and right side of the image.\n"
                "  ⚫ FOV (Field of View) mask: defines the octagonal region of illumination used during alignment of left and right side.\n\n"
                "𝗙𝗼𝗿 𝗻𝗼𝗿𝗺𝗮𝗹𝗶𝘇𝗮𝗶𝗼𝗻, 𝘄𝗲 𝗻𝗲𝗲𝗱:\n"
                "  ⚫ Average background image: already calculated.\n"
                "  ⚫ Stray light: This type of microscopy always is affected by stray reflections. "
                      "The level of this stray light can be found from the `straylight detection region`, which is defined as "
                      "the area between octagonal FOV boundary and rectangular shutter edge.\n\n\n"
                "----------------------------\n"
                "𝗛𝗲𝗹𝗽 𝘁𝗼 𝘁𝗵𝗶𝘀 𝘄𝗶𝗻𝗱𝗼𝘄:\n"
                "----------------------------\n\n"
                "𝗧𝗵𝗶𝘀 𝘄𝗶𝗻𝗱𝗼𝘄 𝗮𝘂𝘁𝗼𝗺𝗮𝘁𝗶𝗰𝗮𝗹𝗹𝘆 𝗲𝘀𝘁𝗶𝗺𝗮𝘁𝗲𝘀:\n"
                "  ⚫ 𝗧𝗵𝗲 𝘀𝗽𝗹𝗶𝘁 𝗽𝗼𝘀𝗶𝘁𝗶𝗼𝗻\n"
                "  ⚫ 𝗧𝗵𝗲 𝗙𝗢𝗩 𝗺𝗮𝘀𝗸\n"
                "  ⚫ 𝗧𝗵𝗲 𝘀𝘁𝗿𝗮𝘆𝗹𝗶𝗴𝗵𝘁 𝗶𝗻𝘁𝗲𝗻𝘀𝗶𝘁𝘆\n\n"
                "However you can still change thevalues by editing the following textboxes.\n"
                "  ⚫ Split position textbox\n"
                "  ⚫ FOV mask textbox:The program performs Otsu thresholding separately for the two halves. "
                     "Changing the default value of 100% will change the intensity thresholds from otsu method accordingly.\n"
                "  ⚫ Straylight thresholds textbox: [Format:Left image min, max, Right image min, max intensity threshold] "
                      "Check the displayed straylight detection overlay to "
                      "ensure the region is correctly identified. To change the mask looks incorrect, edit the intensity thresholds.\n\n"
                "Notes: Some textboxes accept only integer values. If you enter a float, it will be rounded. If you enter non-numeric text, the program will ignore it."
                )
    tk.messagebox.showinfo("Help", help_text)

def show_help_liss_window():
    """Triggered by Help button in Lissjous plotting window (Third window)"""
    help_text=("The goal of this window is to align the left and right halves of the images, "
                     "show the experimental Lissajous plot from a user-defined region of interest (ROI), and fit "
                     "the theoretical Lissajous plot using a gradient descent algorithm.\n\n"
                "Lissajous Plot definition: A plot of the normalized interference intensity at one wavelength "
                     "versus the normalized interference intensity at a second wavelength.\n\n\n"                
                "𝗨𝘀𝗲𝗿 𝗚𝘂𝗶𝗱𝗲:\n"
                "[𝟏] Use the two checkboxes at the top and the image navigation slider to examine the dataset.\n\n"
                "[𝟮] Click the `Perform Registration` button. Visually check the alignment.\n\n"
                "[𝟯] Click the `Draw ROI` button. Left-click on the image to place points that will form the "
                    "ROI polygon. You must place at least three points to proceed. Once the ROI is drawn, " 
                    "click the same button again to finish drawing. Note: the user should ensure that the ROI "
                    "spans from one maxima to the next maxima (or one minimum to the next) for at least one wavelength image.\n\n"
                "[𝟰] Press the Calculate and Fit Lissajous Plot button. The experimental Lissajous plot (scatter plot) will appear. "
                    "The fitting log below the buttons will show the progress of the fitting algorithm. "
                    "Line plots of the fitted theoretical curve will be overlaid on the scatter plot as fitting continues. "
                    "The fitting happens in two stages: first, initialization at multiple points in parameter space; "
                    "then, the best candidate proceeds to a refinement step where final gradient descent is performed. "
                    "This two-step process is necessary because, for each plot, there is a secondary configuration "
                    "(a local minimum) that is different from the global minimum. Once the fitting falls into this local minimum, "
                    "it does not reach the global minimum without reinitialization from another point.\n\n"
                    "Wait for the fitting log to display “gradient descent finished.” If satisfied with the fit, proceed to the next window. "
                    "(Optional) You can adjust the Smoothing parameter textbox for a cleaner scatter plot.\n\n"
                "[𝟱] If unsatisfied with the result, press the Redraw ROI button, draw a new ROI, and fit the Lissajous plot again.\n\n"
                "[𝗡𝗢𝗧𝗘] Make sure that the Lissajous plot is elliptical or circular in nature. "
                     "A narrow, spicular Lissajous plot—where the trace nearly overlaps itself, forming a thin loop, "
                     "is not suitable for analysis. If the interference fringe in an image produces such a "
                     "narrow Lissajous plot, discard that dataset, as it is not suitable for analysis.")
    tk.messagebox.showinfo("Help", help_text)


def show_help_heightmap_window():
    """Triggered by Help button in heightmap calculation window (Fourth window)"""
    pass