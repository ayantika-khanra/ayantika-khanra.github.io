"""
A module containing functions that perform image processing tasks.
"""

import numpy as np
from scipy.ndimage import gaussian_filter1d
from scipy.signal import find_peaks

import cv2, PIL

import tkinter as tk

import os, random

import utils.constants as c 

####################################################################################################

def compute_average_image(file_list):
    """
    Returns the average of a list of images.

    Args:
        file_list (list[str]): A list of file paths 

    Returns:
        np.ndarray: The average image (np.uint16).
    """
    if len(file_list)>100:
        file_list=random.sample(file_list, 100)
    avg_image=None
    for file in file_list:
        image=cv2.imread(file, cv2.IMREAD_UNCHANGED).astype(np.float64)
        if avg_image is None:
            avg_image = image
        else:
            avg_image += image
    avg_image=(avg_image/len(file_list)).astype(np.uint16)
    return avg_image

####################################################################################################

def return_autosegmented_straylight_region(img):
    """
    Automatically segments the straylight detection region in one side of the optosplit image, from 
    detection of histogram second peak that correspond to stray light (the first peak [lowest 
    intensity] corresponds to the region outside the rectangular shutter edge, and the third peak
    [highest intensity] corresponds to the FOV region inside the octangonal FOV)

    Args:
        img (np.ndarray): Input grayscale image (one side).

    Returns:
        tuple:
            - int: Lower cutoff intensity value for double thresholding.
            - int: Upper cutoff intensity value for double thresholding.
            - np.ndarray: Mask of the segmented straylight region.
    """
    hist, bins = np.histogram(img.ravel(), bins=np.arange(-0.1*np.max(img), 1.2*np.max(img),1)) # creating a histogram (intensity vs frequency plot)
    window=(np.max(img)-np.min(img))/100; 
    hist_smooth = gaussian_filter1d(hist, sigma=window,  mode='constant', cval=0) # smoothing the histogram
    prominence =np.max(hist_smooth)/100
    peaks, _ = find_peaks(hist_smooth, prominence=prominence)   # finding peaks
    second_peak_position=bins[peaks[1]]; # finding the second peak intensity
    second_peak_height=hist[peaks[1]]    # finding the second peak frequency
    cutoff=second_peak_height*0.05       # setting cutoff where frequency is at 0.05% of the second peak frequency
    cutoff_crossing_positions=bins[np.where(np.diff(np.sign(hist-cutoff))!=0)[0]]         # finding the intenisty corresponding to these cutoff frequencies
                                                                                          # Logic: hist-cutoff is zero crossing when hist crosses cutoff. np.diff(np.sign(x))!=0 catches the zero crossing points of x where np.sign(x) changes 
    cutoff1=cutoff_crossing_positions[cutoff_crossing_positions<second_peak_position][-1] # The first detected cutoff point BELOW second peak position in plot
    cutoff2=cutoff_crossing_positions[cutoff_crossing_positions>second_peak_position][0]  # The first detected  cutoff point ABOVE second peak position in plot
    segmented_mask=((img>cutoff1) & (img<cutoff2)).astype(np.uint16)                      # mask of the region with intenisty between these two cutoff
    return int(cutoff1), int(cutoff2), close_holes(segmented_mask, 3)                     # holes of size<=3 are closed 

def return_autosegmented_straylight(fullimage, split_position):
    """
    Splits images in left and right, and using return_autosegmented_straylight_region function,
    determines threshold instenities, returns straylight detection region mask, and calculated 
    straylight levels in both sides.

    Args:
        fullimage (np.ndarray): Input grayscale image.
        split_position (int): Where to split the image.

    Returns:
        tuple: 
            - int: lower cutoff intensity for the left region
            - int: upper cutoff intensity for the left region
            - int: lower cutoff intensity for the right region
            - int: upper cutoff intensity for the right region
            - np.ndarray: binary mask of the straylight detection region for the full image
            - float: calculated average straylight intensity for the left region
            - float: calculated average straylight intensity for the right region
    """
    fullimage_left, fullimage_right=split_image(fullimage,split_position)
    left_cutoff1, left_cutoff2, img1_overlay=return_autosegmented_straylight_region(fullimage_left)
    right_cutoff1, right_cutoff2, img2_overlay=return_autosegmented_straylight_region(fullimage_right)
    straylight_overlay=np.hstack((img1_overlay, img2_overlay))
    (left_stray_light, right_stray_light)=calculate_straylight_intensity(fullimage,straylight_overlay,split_position)
    return (left_cutoff1, left_cutoff2, right_cutoff1, right_cutoff2, straylight_overlay,left_stray_light,right_stray_light)

def user_defined_straylight(img,split_position,left_cutoff1,left_cutoff2,right_cutoff1,right_cutoff2):
    """
    Calculates straylight intensity and generates a mask for straylight detection region
    based on user input of upper and lower thresholds of left and right side.

    Args:
        img (np.ndarray): The input grayscale image.
        split_position (int): The column index at which to split the image.
        left_cutoff1 (int): The lower intensity threshold for the left side.
        left_cutoff2 (int): The upper intensity threshold for the left side.
        right_cutoff1 (int): The lower intensity threshold for the right side.
        right_cutoff2 (int): The upper intensity threshold for the right side.

    Returns:
        tuple:
            - float: The average straylight intensity of the left side.
            - float: The average straylight intensity of the right side.
            - np.ndarray: The straylight detection region mask.
    """
    img1, img2=split_image(img,split_position)
    mask1=((img1>left_cutoff1) & (img1<left_cutoff2)).astype(np.uint16)
    mask2=((img2>right_cutoff1) & (img2<right_cutoff2)).astype(np.uint16)
    segmented_mask=np.hstack((mask1,mask2))
    (left_stray_light, right_stray_light)=calculate_straylight_intensity(img,segmented_mask,split_position)
    return left_stray_light, right_stray_light, close_holes(segmented_mask, 3)

def calculate_straylight_intensity(img, mask,split_position ):
    """
    Calculates the average straylight intensity for left and right regions of an image.

    Args:
        img (np.ndarray): The input grayscale image.
        mask (np.ndarray): The binary mask indicating the straylight detection regions.
        split_position (int): The column index at which to split the image.

    Returns:
        (tuple[float, float]): A tuple containing the average straylight intensity
                             for the left and right sides, respectively.
    """
    img_left, img_right=split_image(img,split_position)
    mask_left, mask_right=split_image(mask,split_position)
    left_stray_light=np.sum(img_left*mask_left)/np.sum(mask_left)
    right_stray_light=np.sum(img_right*mask_right)/np.sum(mask_right)
    return (left_stray_light, right_stray_light)

###################################################################################################

def split_image(img,split_position):
    """
    Splits an image into two parts at a specified column.

    Args:
        img (np.ndarray): The input image 
        split_position (int): The column index at which to split the image.

    Returns:
        (tuple[np.ndarray, np.ndarray]): A tuple containing the left and right
                                       parts of the image.
    """
    return img[:, :split_position], img[:, split_position:]

def display_split_line_on_bkgimage(avg_bkg_image,split_position,line_intensity):
    """
    Adds a blue colored split line on a background image.

    Args:
        avg_bkg_image (np.ndarray): The grayscale background image.
        split_position (int):  The column index at which to split the image.
        line_intensity (int): The intensity value of the split line.

    Returns:
        np.ndarray: modified image.
    """
    img=cv2.cvtColor(avg_bkg_image, cv2.COLOR_GRAY2BGR)
    img[:, split_position] = [line_intensity,0,0]
    return img

###################################################################################################

def display_irm_bkg_overlap_image(rep_irm_image,avg_bkg_image,split_position,left_color, right_color):
    """
    Overlays an IRM image onto a background image with different colors for
    left and right sides.

    Args:
        rep_irm_image (np.ndarray): The average IRM image (grayscale).
        avg_bkg_image (np.ndarray): The average background image (grayscale).
        split_position (int): The column index to split the IRM image for coloring.
        left_color (tuple): The BGR color to apply to the left side of the IRM image.
        right_color (tuple): The BGR color to apply to the right side of the IRM image.

    Returns:
        np.ndarray: The blended BGR image.
    """
    split_mask = np.zeros_like(rep_irm_image, dtype=np.uint8); split_mask[:, :split_position] = 1
    img=cv2.cvtColor(rep_irm_image, cv2.COLOR_GRAY2BGR)
    img = (0.5*(img*(split_mask[..., np.newaxis])*left_color + 
                img*(1-split_mask[..., np.newaxis])*right_color)+
            0.5*cv2.cvtColor(avg_bkg_image, cv2.COLOR_GRAY2BGR))
    return img

def display_mask_on_bkgimage(avg_bkg_image,straylight_overlay,max_intensity):
    """
    Overlays the straylight region mask on a background image.

    Args:
        avg_bkg_image (np.ndarray): The grayscale background image.
        straylight_overlay (np.ndarray): The binary straylight mask.
        max_intensity (int): The intensity to use for the overlay.

    Returns:
        np.ndarray: modified image.
    """
    overlay=cv2.cvtColor((straylight_overlay*max_intensity).astype(np.uint16), cv2.COLOR_GRAY2BGR)*np.array([0,0,1])
    img=cv2.cvtColor(avg_bkg_image, cv2.COLOR_GRAY2BGR)
    img=img*0.5+overlay*0.5
    return img

def get_formatted_image(img,max_intensity,min_intensity, canvas=None):
    """
    Formats an image for display in a Tkinter canvas.

    Args:
        img (np.ndarray): The input image
        max_intensity (int): The maximum intensity for clipping.
        min_intensity (int): The minimum intensity for clipping.
        canvas (tk.Canvas, optional): The Tkinter canvas to display the image on. Defaults to None.

    Returns:
        PIL.ImageTk.PhotoImage: The formatted and resized image for display in a Tkinter GUI.
    """
    img =clip_image(img, min_intensity, max_intensity)
    if len(img.shape) == 2: # Grayscale
        im_pil = PIL.Image.fromarray(img)
    else: # Color (assuming BGR from OpenCV)
        im_pil = PIL.Image.fromarray(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))

    if canvas:
        canvas_width = canvas.winfo_width() or 800; canvas_height = canvas.winfo_height() or 400
        im_pil.thumbnail((canvas_width, canvas_height))
    else:
        s1=c.screensize()[0]/2; s2=c.screensize()[1]/2
        if (im_pil.size[0] > s1) or (im_pil.size[1] > s2):
            im_pil.thumbnail((s1,s2))
        else:
            scale=min(s1/im_pil.size[0], s2/im_pil.size[1])
            im_pil = im_pil.resize((int(im_pil.size[0]*scale), int(im_pil.size[1]*scale)))

    tk_image = PIL.ImageTk.PhotoImage(image=im_pil)
    if canvas:
        canvas.delete("all")
        canvas.create_image(canvas_width//2, canvas_height//2, image=tk_image, anchor=tk.CENTER)
    return tk_image
        
##################################################################################################

def otsu_thresholding(img, split_position, eff_thresh=100.0):
    """
    Split image into two halves, applies Otsu's thresholding to each side.

    Args:
        img (np.ndarray): The input grayscale image.
        split_position (int): The column index where to split the image.
        eff_thresh (float, optional): A percentage multiplier for the Otsu threshold. Defaults to 100.0.

    Returns:
        np.ndarray: The combined binary mask from both halves of the image.
    """
    img1, img2=split_image(img,split_position)
    thresh_value1, _ = cv2.threshold(img1, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    thresh_value2, _ = cv2.threshold(img2, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    otsu_mask1 = img1>thresh_value1*eff_thresh/100.0
    otsu_mask2 = img2>thresh_value2*eff_thresh/100.0
    return np.hstack([otsu_mask1,otsu_mask2]).astype(np.uint16)

###################################################################################################

def match_image_size(img1, img2):
    """
    Matches the width of two images (same height) by padding right side of the smaller one.

    Args:
        img1 (np.ndarray): The first image.
        img2 (np.ndarray): The second image.

    Returns:
        tuple[np.ndarray, np.ndarray]: The modified first image, the modified second image.
    """
    padding=img1.shape[1]- img2.shape[1]
    if padding>0:
        img2 = cv2.copyMakeBorder(img2, 0, 0, 0,padding, borderType=cv2.BORDER_CONSTANT, value=0)
    else:
        img1 = cv2.copyMakeBorder(img1, 0, 0, 0,-padding, borderType=cv2.BORDER_CONSTANT, value=0)
    return img1, img2

def calculate_shift_needed_for_registration(img,split_position):
    """
    splits an image and calculates the translational shift required to register two halves of an image.

    Args:
        img (np.ndarray): The input image.
        split_position (int): The column index to split the image.

    Returns:
        np.ndarray: A 2x3 affine transformation matrix
    """
    fixed,moving=split_image(img,split_position)
    fixed,moving=match_image_size(fixed-np.mean(fixed),moving-np.mean(moving)); 
    (dx,dy), _ = cv2.phaseCorrelate(fixed, moving)
    shift_by= np.float32([[1, 0, -dx], [0, 1, -dy]])
    return shift_by

###################################################################################################

def split_and_overlay(img,FOV_mask,split_position, left_color,right_color,shift_by=None):
    """
    Splits, and overlays two halves of an image, with appropriate colors for each half

    Args:
        img (np.ndarray): The input image.
        FOV_mask (np.ndarray): The FOV mask.
        split_position (int): The column index for splitting the image.
        left_color (tuple): The BGR color for the left half.
        right_color (tuple): The BGR color for the right half.
        shift_by (np.ndarray, optional): An affine transformation matrix for shifting the right half. 

    Returns:
        np.ndarray: The overlaid and colorized image (np.uint8)
    """
    left_image, right_image=split_image(img,split_position)
    left_image_mask, right_image_mask=split_image(FOV_mask,split_position)
    left_min,left_max=np.percentile(left_image[left_image_mask.astype(bool)],5),np.percentile(left_image[left_image_mask.astype(bool)],95)
    right_min,right_max=np.percentile(right_image[right_image_mask.astype(bool)],5),np.percentile(right_image[right_image_mask.astype(bool)],95)
    left_image,right_image=match_image_size(left_image,right_image)
    if shift_by is not None:
        right_image = cv2.warpAffine(right_image, shift_by, (left_image.shape[1], left_image.shape[0]))
    left_image_toshow=clip_image(left_image,0.5*left_min,1.5*left_max)
    right_image_toshow=clip_image(right_image,0.5*right_min,1.5*right_max)
    img=left_image_toshow[..., np.newaxis]*left_color+right_image_toshow[..., np.newaxis]*right_color
    return img.astype(np.uint8)

def overlay_roi(img,roi_points):
    """Draws a region of interest (ROI) polygon on an image.

    Args:
        img (np.ndarray): The input image
        roi_points (list[tuple[int, int]]): A list of (x, y) coordinates.

    Returns:
        np.ndarray: The input image with the ROI region drawn on it.
    """
    if len(roi_points)>1:
        for i in range(1,len(roi_points)):
            cv2.line(img, roi_points[i], roi_points[i-1], (255,0,0), thickness=2, lineType=cv2.LINE_AA)
    if len(roi_points)>0:
        for pts in roi_points:
            cv2.circle(img, pts, radius=3, color=(0, 0, 0), thickness=-1)
    return img


##############################################################################

def close_holes(mask, size):
    """Performs a morphological closing operation to fill holes in a mask.

    Args:
        mask (np.ndarray): The input binary mask
        size (int): The max size of holes that should be closed

    Returns:
        np.ndarray: output mask
    """
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (size,size))
    closed_mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)
    return closed_mask

def mask_from_polygon(img_shape, roi_points):
    """Creates a mask from a list of polygon points.

    Args:
        img_shape (tuple[int, int]): What the output mask shape should be.
        roi_points (list[tuple[int, int]]): A list of (x, y) coordinates

    Returns:
        np.ndarray: A binary mask with the polygonal area filled.
    """
    mask = np.zeros(img_shape, dtype=np.uint8)
    pts = np.array(roi_points, dtype=np.int32).reshape((-1, 1, 2))
    cv2.fillPoly(mask, [pts], 255)
    return mask

def clip_image(img, min_, max_):
    """Clips and scales an image to a 8-bit range.

    Args:
        img (np.ndarray): The input image 
        min_ (int or float): The minimum pixel value to clip to. 
        max_ (int or float): The maximum pixel value to clip to. 

    Returns:
        np.ndarray: modified image (np.uint8)
    """
    img = np.clip(((img.astype(np.float32)- min_)/(max_-min_)*255),0,255).astype(np.uint8)
    return img







#######################################################
def overlay_filled_roi(img,roi_points):
    if len(roi_points) > 2:
        pts = np.array([roi_points], dtype=np.int32)
        overlay = img.copy()
        cv2.fillPoly(overlay, pts, color=(255, 0, 0))
        img = cv2.addWeighted(overlay, 0.7, img, 0.3, 0)
    return img