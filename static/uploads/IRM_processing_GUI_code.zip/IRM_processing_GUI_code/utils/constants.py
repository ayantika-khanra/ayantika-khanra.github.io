"""
Module for storing experimental constants. These constants are specific to someone's 
Interference microscopy setup

- `left_color`, `right_color`: color (BGR format) used to display the left and right 
   channel images in the GUI, scaled to max of 1. i.e. white is represented as [1,1,1].

- `delh_left`, `delh_right`: Height difference between interference intensity maxima 
   and consecutive minima. Typically determined with calibration experiments. 
   If callibration hasnt been performed, approximation delh=lambda/4n, where lambda
   is wavelength and n is medium refractive index (1.333 for water for biological 
   samples) is sufficient. 

- screensize: a function to determine user's screensize

- `fontfamily` and `fontsize`: sets font style for gui elements
""" 

import numpy as np
import pyautogui
def screensize():
   size = pyautogui.size()
   return (size.width,size.height) 

left_color=np.array([0,1,0]); right_color=np.array([0,0,1]) # [B, G, R]
delh_left=0.11064;  delh_right=0.12832
fontfamily="Segoe UI"; fontsize=13
