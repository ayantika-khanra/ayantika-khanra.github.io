"""
Module with functions to compute experimental and theoretical Lissajous plots
and to fit an experimental plot to a theoretical curve using gradient descent.
"""

# importing libraries
import numpy as np
import cv2
import torch
import random
import utils.gui_utils as guiutil     # Contains utility functions for GUI widget creation and updating
import utils.cv_utils as cvutil       # utility functions for image processing 

#==================================================================================================

def get_intensity_pairs_from_roi(image_files, bkg_avg_image, split_position,shift_by, 
                                 liss_smooth, left_stray_light, right_stray_light, 
                                 roi_points):
    """
    An "intensity pair" of a pixel is the normalized intensity values of that pixel 
    in the left and right side images (after alignment). This function calculates 
    `intensity pairs` for pixels within the specified ROI across multiple image files. 
     - Note: The returned intensity-pair data is sampled from only a subset of pixels 
        and images for efficiency.
     - Note: Normalized intenisty= (IRM_image-stray_light)/(bkg_image-stray_light) 

    Parameters:
       image_files (list of str): Paths to IRM image files to be analyzed.
       bkg_avg_image (np.ndarray): Average Background image.
       split_position (int): x-coordinate where images are split into left and right halves.
       shift_by (np.ndarray): Affine transformation matrix used to align the right half of images.
       liss_smooth (float): Smoothing parameter for Gaussian blur of images.
       left_stray_light (float): stray light intensity for the left side image.
       right_stray_light (float): stray light intensity for the right side image
       roi_points (list of tuples): list of Polygon points ((x,y) tuple) defining the region of interest (ROI)
                                      for intensity calculation

    Returns:
        (list of np.ndarray):
        - np.ndarray: Normalized intensities for a pixel in left half of images
        - np.ndarray: Normalized intensities for the smae pixel in the right half

    """

    # split and align images
    left_bkg_img, right_bkg_img=cvutil.split_image(bkg_avg_image,split_position)          
    left_bkg_img, right_bkg_img=cvutil.match_image_size(left_bkg_img, right_bkg_img)
    right_bkg_img = cv2.warpAffine(right_bkg_img, shift_by, 
                                    (left_bkg_img.shape[1], left_bkg_img.shape[0])).astype(np.uint16)
    
    # create mask corresponsing to ROI, create a square kernel for smoohting, sample random
    # images from `image_files` list
    mask = cvutil.mask_from_polygon(left_bkg_img.shape, roi_points).astype(bool)
    num_images=min(len(image_files), max(40, 10000//np.sum(mask)+1))       # num_images ~ 10000/num_of_pixels_in_ROI, capped at max value of 40, 
    random_images = random.sample(image_files, num_images)  # and importantly capped at min value of len(image_files)
    kernel_len=int(liss_smooth*6) 
    if kernel_len % 2 == 0: kernel_len += 1 # `kernel_len` has to be odd
    kernel_size = (kernel_len, kernel_len)  
    left_bkg_img = cv2.GaussianBlur(left_bkg_img, kernel_size, liss_smooth)
    right_bkg_img = cv2.GaussianBlur(right_bkg_img, kernel_size,liss_smooth)
    
    all_left_intensities = []; all_right_intensities = [];
    for image_path in random_images:
        # split and align and blur images
        img = cv2.imread(image_path, cv2.IMREAD_UNCHANGED).astype(np.uint16)
        left_img, right_img=cvutil.split_image(img,split_position)
        left_img, right_img=cvutil.match_image_size(left_img, right_img)
        right_img = cv2.warpAffine(right_img, shift_by, 
                                   (left_img.shape[1], left_img.shape[0])).astype(np.uint16)
        left_img = cv2.GaussianBlur(left_img, kernel_size, liss_smooth)   #GaussianBlur preserves image size
        right_img = cv2.GaussianBlur(right_img, kernel_size,liss_smooth)
        # intensity normalization
        left_img_norm= (left_img.astype(np.float32)-left_stray_light)/(left_bkg_img.astype(np.float32)-left_stray_light); 
        right_img_norm=(right_img.astype(np.float32)-right_stray_light)/(right_bkg_img.astype(np.float32)-right_stray_light); 
        
        all_left_intensities.append(left_img_norm[mask])
        all_right_intensities.append(right_img_norm[mask])
    
    all_left_intensities=np.concatenate(all_left_intensities)
    all_right_intensities=np.concatenate(all_right_intensities)
    
    # Sampling/shuffling of intensity pairs. maximum number of intensity pair selected is 10000.
    idx = np.random.choice(len( all_left_intensities), size=min(len(all_left_intensities), 10000), replace=False)
    intensity_pair=[all_left_intensities[idx], all_right_intensities[idx]]
    
    return intensity_pair

#==================================================================================================

def fit_lissajous(data, delh_left,delh_right, comm_queue):
    """
    Fits a Lissajous curve relationship between left and right intensity data using gradient descent 
    (PyTorch’s Adam optimizer) by optimizing six parameters `I_mid_left`, `I_mod_left`, `I_mid_right`, 
    `I_mod_right`, `phi` and `x_mid`. Optimization is done in two stages: initialization (mode='init') to 
    randomize the initial value of `x_mid`, as without that optimization often gets stuck in a specific
    local minima curve that is very close to the global minima curve, and refinement (mode='refine') 
    where gradient descent is run from the initialization with the lowest loss.

    Parameters:
        data (list): A list containing two numpy 1D arrays representing normalized intensity data 
            from left and right sides.
        delh_left (float): periodic length parameter for the wavelength corresponding to the left-side image.
        delh_right (float): Same as above but for the right side.
        comm_queue (queue.Queue): communication queue for sending progress updates or 
            intermediate fit results (to display in canvas widget and 
            fitting label widget of the lissajous window in the GUI).

    Returns:
        None: results are sent in communication queue instead.
    """

    if comm_queue: 
        comm_queue.put("Starting Gradient Descent") 
    
    I_left=data[0]; I_right=data[1];
    # `x_span` corresponds to one loop of lissajous plot, `x_mid` corresonds to a shift added to it
    # The input to the Lissajous function is therefore: `x` = `x_span` + `x_mid` 
    x_span_arr=2* np.linspace(-delh_right/2,delh_right/2,100) 
    x_span = torch.tensor(x_span_arr, dtype=torch.float32).reshape(1, -1)

    #Initial values of first 5 parameters
    init_vals=[1.0, (I_left.max() - I_left.min())/2,      #  `I_mid_left`, `I_mod_left`
               1.0, (I_right.max() - I_right.min())/2,    #  `I_mid_right`,`I_mid_right`
               np.pi/2 ]                                  #  `phi`
    
    #specifics of `init` and `refine` modes
    num_datapts=  {'init':500,  'refine':10000} # Number of data points to sample for fitting
    fit_repeats=  {'init':8,    'refine':1    } # Number of times to initialize the fit with different starting points (x_mid values)
    num_iteration={'init':500,  'refine':200  } # Number of iterations to run
    lr=           {'init':0.01, 'refine':0.003} # Learning rate

    for mode in ['init', 'refine']:
        # a subset of data is selected
        N = min(len(I_left), num_datapts[mode])
        I_left_data = torch.tensor(I_left[:N], dtype=torch.float32).reshape(-1, 1)
        I_right_data = torch.tensor(I_right[:N], dtype=torch.float32).reshape(-1, 1)

        loss_array=[];parameter_array=[]
        for i in range(fit_repeats[mode]):
            # Initializing the six parameters (these will be optimized)
            (I_mid_left, I_mod_left, 
             I_mid_right, I_mod_right, phi) = [torch.nn.Parameter(torch.tensor([val], dtype=torch.float32))
                                              for val in init_vals]
            if mode=='init':
                x_mid = torch.nn.Parameter(torch.tensor([ np.random.random()*6*delh_left], # `x_mid` is initiated at a random 
                                                        dtype=torch.float32))              # point between 0 and 6*delh_left
            else:
                x_mid = torch.nn.Parameter(torch.tensor([xmid_best],                       # `x_mid` is initiated at the best
                                                        dtype=torch.float32))              # fit from intialization stage

            params = [I_mid_left, I_mod_left, I_mid_right, I_mod_right, phi, x_mid]
            optimizer = torch.optim.Adam(params, lr=lr[mode])
            for step in range(num_iteration[mode]):
                optimizer.zero_grad()
                x = x_span + x_mid
                # Theoretical lissajous curve, parametric form (`Ith_left` in x axis, `Ith_right` in y axis)
                Ith_left = I_mid_left + I_mod_left * torch.sin(torch.pi * x / delh_left)
                Ith_right = I_mid_right + I_mod_right * torch.sin(torch.pi * x / delh_right + phi)

                cost_matrix = (Ith_left - I_left_data)**2 + (Ith_right - I_right_data)**2
                cost_per_point = torch.min(cost_matrix, dim=1).values

                loss = torch.mean(cost_per_point)
                loss.backward()
                optimizer.step()

                # Periodically send progress updates through comm_queue, which can be either 
                # - a string 
                # - or a dictionary containing `x` (=x_span+x_mid) and fit_params
                if comm_queue: 
                    fit_params = tuple(p.detach().item() for  p in  params)
                    result_data = {'x': x_span_arr+fit_params[5],'fit_params': fit_params}
                    if (mode=='init') and (step % 100 == 0):
                        comm_queue.put(f"Initialization {i+1} / Step {step}: loss = {loss.item():.6f}")
                        comm_queue.put(result_data)   
                    if (mode=='refine') and ((step % 10 == 0) or (step == num_iteration[mode]-1)):
                        comm_queue.put(f"Refining / Step {step}: loss = {loss.item():.6f}")
                        comm_queue.put(result_data)     
            if mode=='init':
                # Store fit parameters and loss for this repeat 
                fit_params = tuple(p.detach().item() for  p in  params)
                x= x_span_arr+fit_params[5];
                parameter_array.append((x,fit_params))
                loss_array.append(loss.item())

        # Select best fit (lowest loss) from initialization runs, and start the `refine` mode with those parameters
        if mode=='init':
            idx=np.argmin(np.array(loss_array)); (_,fit_params_best)=parameter_array[idx]
            init_vals=fit_params_best[:5]; xmid_best=fit_params_best[5]
        if mode=='refine':                           #when refine  mode optimization is over, 
            if comm_queue:
                comm_queue.put("Gradient Descent Finished.")

def get_fit_plot(x, fit_params,  delh_left,delh_right ):
    """
    Calculates theoretical Lissajous intensity curves for the left and right channels.

    Parameters:
        x (1D array): height
        fit_params (tuple): containing (I_mid_left, I_mod_left, I_mid_right, I_mod_right, phi, x_mid(ignored)),
        delh_left (float): periodic length parameter for the wavelength corresponding to the left-side image.
        delh_right (float): same as above for the right-side image.

    Returns:
        (tuple of arrays):
         - Ith_left (1D array): computed left-channel intensity values.
         - Ith_right (1D array): computed right-channel intensity values.
    """

    (I_mid_left,I_mod_left,I_mid_right,I_mod_right,phi,_)=fit_params
    Ith_left = I_mid_left + I_mod_left * np.sin(np.pi * x / delh_left)
    Ith_right = I_mid_right + I_mod_right * np.sin(np.pi * x / delh_right + phi)
    return Ith_left, Ith_right



