import numpy as np
from scipy.special import jv
import cv2

"""
This module provides a simplified simulation of interference reflection microscopy (IRM) imaging.

It includes functions to:
- Generate a point spread function (PSF) to simulate the effect of the microscope's optics.
- Convert a height map into an IRM intensity image.
- Apply various microscopy effects to an IRM intensity map, such as illumination inhomogeneity,
  PSF blurring, rectangular shutter edge of optosplit, field diaphragm edge, stray light, and camera shot noise, 
  common in IRM microscopy.
- To simulate the working of optosplit component in a microscope, embed simulated microscopy images at
  two different wavelengths side-by-side into a larger frame with a small distance between them.
"""

def PSF(lambda_,NA, xd, size_scaled=8):
    """
    Creates a microscope Point Spread Function (PSF) based on the Airy disk pattern.

    Args:
        `lambda_` (float): The wavelength of the illumination light.
        NA (float): The numerical aperture of the microscope objective.
        xd (float): The pixel size of the camera.
        size_scaled (int, optional): size of the PSF kernel/2 (in units of r0=lambda/(2*NA)). Defaults to 8.

    Returns:
        numpy.ndarray: the normalized PSF kernel.
    """
    r0=lambda_/(2*NA)
    span=int((r0*size_scaled/xd)/2)
    x=np.arange(-span,span+1, 1)*xd; y=x; 
    (x,y)=np.meshgrid(x,y)
    r=np.sqrt(x**2+y**2); r[span,span]=np.nan # the center is set to nan as the numerator of `psf_kernel` formula can blow up at r=0
    psf_kernel=(2* jv(1, np.pi*r/r0)/ (np.pi*r/r0) )**2       # Airy pattern formula using the Bessel function of the first kind (jv)
    psf_kernel=np.where(np.isnan(psf_kernel), 1, psf_kernel)  # the center of `psf_kernel` (r=0) is set to 1
    return psf_kernel/np.sum(psf_kernel)                      # normalize `psf_kernel` returned

def height_to_IRM_intensity(I_illumination, h, del_h,I_mod, I_mid=1,  h_avg=0):
    """
    Converts a height map to an Interference Reflection Microscopy (IRM) intensity map.

    Args:
        I_illumination (float or numpy.ndarray): illumination intensity
        h (numpy.ndarray): A 2D array representing height map of the sample.
        del_h (float): The height difference between maximum and consecutive minimum interference intensity.
        I_mod (float): Modulation intensity. This controls the contrast of the fringes.
        I_mid (float, optional): Avergae intensity of the interference pattern. Defaults to 1.
        h_avg (float, optional): represents a phase shift term in interference intensity equation. Defaults to 0.

    Returns:
        numpy.ndarray: calculated IRM intensity map.

    Note: I_mod, I_mid, h_avg and del_h is typically determined from experiments or optics simulation.
    """
    return I_illumination*(I_mid+I_mod*np.sin(np.pi*(h-h_avg)/del_h)) # a formula for how interference intensity varies with height. 

def microscopy_effect_on_IRM_intenisty_map(IRM_intensity, fov_mask=1, illum_imhomogenity=1, 
                                           psf_kernel=1, stray_light=0,shot_noise=False ):
    """
    This function takes an ideal IRM intensity map and adds realistic effects of IRM microscopy, 
    such as uneven illumination, blurring due to the point spread function (PSF), rectangular 
    shutter edge of optosplit, field diaphragm edge, stray light, and camera shot noise.

    Args:
        IRM_intensity (numpy.ndarray): The input ideal IRM intensity map.
        fov_mask (numpy.ndarray or int, optional): A mask to simulate the octagonal field diaphragm edge. 
                                                   Defaults to 1, which means no FOV mask.
        illum_imhomogenity (numpy.ndarray or int, optional): A map for uneven illumination. 
                                                            Defaults to 1, which means no uneven illumination.
        psf_kernel (numpy.ndarray or int, optional): The point spread function kernel for blurring. 
                                                     Defaults to 1, representing that no psf effect is required.
        stray_light (float, optional): A constant value added to simulate stray light. Defaults to 0.
        shot_noise (bool, optional): If True, adds Poisson-distributed shot noise. Defaults to False.

    Returns:
        numpy.ndarray: The IRM intensity map.
    """
    IRM_intensity=IRM_intensity*illum_imhomogenity
    IRM_intensity=IRM_intensity*fov_mask/np.max(fov_mask)+stray_light
    #2. add PSF effect  
    IRM_intensity_blurred = cv2.filter2D(IRM_intensity, -1, psf_kernel, borderType=cv2.BORDER_CONSTANT)
    if shot_noise:
        IRM_noise = np.random.normal(loc=0, scale=np.sqrt(np.clip(IRM_intensity_blurred, 0, None)))
        IRM_intensity_blurred=IRM_intensity_blurred+IRM_noise
    return IRM_intensity_blurred

def embed_in_a_rectangular_frame(microscopy_intensity_left, microscopy_intensity_right, 
                                 split=0.05, border=0.015, camera_offset=0):
    """
    Embeds two microscopy images at different wavelengths side-by-side into a single rectangular frame.

    Args:
        microscopy_intensity_left (numpy.ndarray): The left image.
        microscopy_intensity_right (numpy.ndarray): The right image.
        split (float, optional): the distance between the two images divided by the width of one image. Defaults to 0.05.
        border (float, optional): the border around the entire image divided by the width of one image. Defaults to 0.015.
        camera_offset (float, optional): camera sensor offset. Defaults to 0.
                                         Random noise proportional to the square root of this offset is also added. 

    Returns:
        numpy.ndarray: The combined image.
    """
    width=microscopy_intensity_left.shape[0]
    split_pixels=int(split*width); border_pixels=int(border*width);
    embeded_image=np.zeros([microscopy_intensity_left.shape[0]+border_pixels*2,microscopy_intensity_left.shape[1]*2+border_pixels*2+split_pixels] )
    embeded_image[border_pixels:border_pixels+microscopy_intensity_left.shape[0], 
                 border_pixels:border_pixels+microscopy_intensity_left.shape[1]]=microscopy_intensity_left
    embeded_image[border_pixels:border_pixels+microscopy_intensity_right.shape[0], 
                 border_pixels+microscopy_intensity_left.shape[1]+split_pixels:
                 border_pixels+2*microscopy_intensity_left.shape[1]+split_pixels]=microscopy_intensity_right
    embeded_image=(embeded_image+np.ones_like(embeded_image)*camera_offset+
                   np.random.normal(loc=0, scale=np.sqrt(camera_offset), size=embeded_image.shape))
    return embeded_image