"""
This module provides utilities for generating time-series data of 2D height maps that
simulate thermal fluctuations of passive membranes. It alos contains functions for analyzing
power spectrum of height maps.
"""

import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from matplotlib import animation

def height_map_from_FFT(QX,QY,dft_shifted):
    """
    Calculates real-space height map from its Fourier-space representation, via inverse FFT.

    Args:
        QX (numpy.ndarray): q-space coordinates in the x-direction (2D grid from meshgrid, square shape).
        QY (numpy.ndarray): q-space coordinates in the y-direction (2D grid from meshgrid, square shape).
        dft_shifted_modified (numpy.ndarray): A 2D complex array representing the
            shifted FFT of the height map, with zero frequency at the center.

    Returns:
        tuple: A tuple containing:
            - X (numpy.ndarray): real-space coordinates in the x-direction (2D grid)
            - Y (numpy.ndarray): real-space coordinates in the y-direction (2D grid)
            - modified_heightmap_colorednoise (numpy.ndarray): real-space height map (2D array).
    """
    if (QX.shape != QY.shape) or (QX.shape != dft_shifted.shape) or (QX.shape[0] != QX.shape[1]):
        raise ValueError("QX, QY and  dft_shifted should have the same shape")
    dft_modified = np.fft.ifftshift(dft_shifted)
    heightmap = np.real(np.fft.ifft2(dft_modified ))
    heightmap=heightmap-np.mean(heightmap)
    num_of_pixels=QX.shape[1]
    qxd=abs(QX[0,0]-QX[0,1]); 
    xd=2*np.pi/((num_of_pixels-1)*qxd)     # real-space pixel size (xd) from the q-space grid spacing (qxd)
    x = np.arange(0,num_of_pixels,1)*xd; y = x
    X, Y = np.meshgrid(x, y)
    return (X,Y,heightmap)

def generate_thermal_fluc_heightmap_testdata(xd,num_of_pixels,colored_spectrum_function,
                                             dt, num_frames,time_evolution_function, 
                                             stabilization_time_frame=0,  amplitude_scaling=1, 
                                             equilibrium_height_profile=lambda x, y: 0,
                                             show_progress=False, test_stationarity=False, 
                                             saveas=None, video_saveas=None):
    """
    Generates a time-series of 2D height maps simulating thermal fluctuations, 
    with a specified power spectrum, and frequency dependent temporal correlations.

    Args:
        xd (float): pixel size
        num_of_pixels (int): The number of pixels along one side of the 2D height map.
        colored_spectrum_function (callable): A function representing the desired power 
                                              spectrum <|h(q)|^2>, where q is wavenumber.
                                              For example, for bending only fluctuation
                                              if bending rigidity is 10 kBT this function 
                                              would be lambda q: 1/(10*q**4)
        dt (float): The time step between frames.
        num_frames (int): The number of frames to generate and store.
        time_evolution_function (callable): Function that determined the relaxation rate 
                                            of a mode of wavenumber q.  In biomembrane literature 
                                            this is denoted as tau(q). For example:
                                            lambda q: 1/(80*q+180*(q**3)).
        stabilization_time_frame (int, optional): Number of initial frames that are generated but
                                                  discarded, aso that the simulation reaches a steady 
                                                  state. Defaults to 0.
        amplitude_scaling (float, optional): A factor to scale the amplitude of the fluctuations.
                                             Defaults to 1.
        equilibrium_height_profile (callable, optional): A function of (X, Y) that defines equillibrium 
                                                         average height map, on top of which the height 
                                                         fluctuations occur. Defaults to a flat plane lambda x, y: 0.
        show_progress (bool, optional): If True, prints the frame number every 10 frames. Defaults to False.
        test_stationarity (bool, optional): If True, plots the standard deviation of height
                                            over time to check for stationarity. Defaults to False.
        saveas (str, optional): If provided, the path to save the generated height map
                                time-series as a .npy file. Defaults to None.
        video_saveas (str, optional): If provided, the path to save an animated video of the
                                      height map evolution. Defaults to None.

    Returns:
        tuple or list: 
         - If `test_stationarity` is True, returns a list of the heightstandard deviations per frame. 
         - Otherwise, returns a tuple containing (X, Y, height_map_timeseries)
    """
    stationarity_test_output=[]
    height_map_timeseries=[]
    for i in range(num_frames+stabilization_time_frame):
        nn=int((num_of_pixels-1)/2)
        FT_of_whitenoise = (np.random.normal(size=[num_of_pixels,num_of_pixels])          # Generate complex white noise
                            +(1j)* np.random.normal(size=[num_of_pixels,num_of_pixels]))
        qxd=2*np.pi/((num_of_pixels-1)*xd); qx=np.arange(-nn, (nn+1), 1)*qxd; qy=qx;
        QX,QY=np.meshgrid(qx,qy)
        Q=np.sqrt(QX**2+QY**2);Q[nn,nn]=1 # Avoid division by zero at the center (q=0, DC component, later discarded).
        
        # AR(1) process is x_t ​= rho * x_{t−1} ​+ \sqrt(1−rho**2) ​ε_t​
        # autocorrelation function (ACF) of AR(1) process is rho^∣k∣, where k is the timestep number, 
        # i.e., k=t/dt where dt is timegap between frames. or: ACF=exp(log(rho)t/dt)
        # As, helfrich autocorrelation fucntion is exp(-t/tau(q)), we can say, tau(q)=-dt/log(rho)
        rho=np.exp(-1/(time_evolution_function(Q)/dt))    
        if i>0:                                          # Introduce temporal correlation using an AR(1) process
            FT_of_whitenoise=rho*last_FT_of_whitenoise+(np.sqrt(1-rho**2))*FT_of_whitenoise; 
        dft_shifted_modified_colorednoise=FT_of_whitenoise*np.sqrt(colored_spectrum_function(Q))
        (X,Y,Z)=height_map_from_FFT(QX,QY,dft_shifted_modified_colorednoise)
        Z=amplitude_scaling*Z+equilibrium_height_profile(X,Y)# adding amplitude scaling and equillibrium height profile
        if i>=stabilization_time_frame:                      # after stabilization is complete, start adding height map to the height_map_timeseries 
            height_map_timeseries.append(np.array(Z, dtype='float32'))
        last_FT_of_whitenoise=FT_of_whitenoise
        stationarity_test_output.append(np.std(Z))
        if show_progress:
            if i%10==0:
                print(i)
    height_map_timeseries=np.stack(height_map_timeseries, axis=-1)
    if saveas is not None:
        np.save(saveas, height_map_timeseries)
    if video_saveas is not None:
        save_heightmap_as_movies(X,Y, height_map_timeseries, video_saveas)
    if test_stationarity:
        plt.figure();plt.plot(stationarity_test_output);
        plt.xlabel("Frame Number"); plt.ylabel("Height Variance")
        plt.show()
        return(stationarity_test_output)
    else:
        return (X,Y,height_map_timeseries)

def calculate_cosine_FFT(height_map,xd):
    """
    Calculates the cosine 2D FFT of a height map.

    Args:
        height_map (numpy.ndarray): The 2D input height map. Should be square.
        xd (float): The pixel size

    Returns:
        tuple: 
            - QX (numpy.ndarray): 2D grid of q-space coordinates in the x-direction.
            - QY (numpy.ndarray): 2D grid of q-space coordinates in the y-direction.
            - dft_cosine (numpy.ndarray): The cosine 2D FFT
    """
    if height_map.shape[0] != height_map.shape[1]:
        raise ValueError("height_map should be square")
    num_of_pixels=height_map.shape[1]
    nn=(num_of_pixels-1)/2
    dft = np.fft.fft2(height_map) 
    dft_shifted = np.fft.fftshift(dft)                   # shift the zero frequency to the center
    qxd=2*np.pi/((num_of_pixels-1)*xd);                  # Calculate q-space coordinates
    qx=np.linspace(-nn, nn, num_of_pixels)*qxd; qy=qx;
    QX,QY=np.meshgrid(qx,qy)
    L=num_of_pixels*xd                                   # real length of the square height map
    dft_cosine=np.real(dft_shifted)*xd*xd*np.sqrt(2/(L**2))      # xd*xd*np.sqrt(2/(L**2)) factor added according to Helfrich formalism
    return (QX,QY,dft_cosine)

def plot_power_spectrum_2D(height_map_timeseries,xd):
    """
    Calculates and plots the power spectrum of a height map time-series

    Args:
        height_map_timeseries (numpy.ndarray): A 3D array (height, width, time) of height maps.
                                               height_map_timeseries[:, :, i] is the 2D height map at time i.
        xd (float): The pixel size.
    """
    num_of_pixels=height_map_timeseries.shape[1]
    equilibrium_height_profile = np.reshape(np.mean(height_map_timeseries, axis=-1),(num_of_pixels,num_of_pixels,1))
    height_map_timeseries=height_map_timeseries-equilibrium_height_profile       # Subtract the mean height profile (equilibrium shape)
    dft_magnitude_sum_squared=0
    num_of_slice=height_map_timeseries.shape[-1]
    for i in range(num_of_slice):
        (QX,QY,dft_cosine)=calculate_cosine_FFT(height_map_timeseries[:,:,i],xd) # Calculate the cosine FFT
        Q=np.sqrt(QX**2+QY**2);
        dft_magnitude_sum_squared=dft_magnitude_sum_squared+dft_cosine**2        # Sum the square of the amplitudes
    dft_magnitude_mean_squared=dft_magnitude_sum_squared/num_of_slice            # get the mean-squared amplitude
    plt.figure(); plt.scatter(Q.ravel(),dft_magnitude_mean_squared.ravel() ); 
    plt.ylabel('$<A_q>^2$');plt.xlabel('q');
    plt.xscale('log');plt.yscale('log');
    plt.show()


def save_heightmap_as_movies(X,Y, height_map_store, filename):
    """
    Creates and saves an animated video of 3D surface plot of the height map time-series.

    Args:
        X (numpy.ndarray): x-coordinates (2D grid from meshgrid).
        Y (numpy.ndarray): y-coordinates (2D grid from meshgrid).
        height_map_store (numpy.ndarray): 3D array (height, width, time) of the height maps.
                                          height_map_store[:, :, i] is the 2D height map at time i.
        filename (str): The output path of video file.
    """
    if not animation.writers.is_available('ffmpeg'):
        raise RuntimeError("FFmpeg writer is not available. Install it.\n")
    if height_map_store.shape[-1] == 0:
        raise ValueError("can't create animation from empty `height_map_store` (0 frames).")
    if X.shape != height_map_store[:, :, 0].shape or Y.shape != height_map_store[:, :, 0].shape:
        raise ValueError("height_map_store[:, :, i] shape should be equal to X.shape and Y.shape")
    num_slices = height_map_store.shape[-1]
    zmin, zmax = np.min(height_map_store), np.max(height_map_store)  # Determine the z-axis limits for consistent plotting
    fig = plt.figure(); ax = fig.add_subplot(111, projection='3d')
    surf = [ax.plot_surface(X, Y, height_map_store[:, :, 0], cmap='viridis')]
    # Function to update the plot for each frame of the animation
    def update(frame):
        ax.clear()
        ax.set_zlim(zmin, zmax)
        ax.set_xlabel('X'), ax.set_ylabel('Y'), ax.set_zlabel('Height')
        ax.set_title(f'Frame: {frame+1}/{num_slices}')
        return ax.plot_surface(X, Y, height_map_store[:, :, frame], cmap='viridis'),
    anim = animation.FuncAnimation(fig, update, frames=num_slices, interval=50)     # Create the animation object
    anim.save(filename, writer='ffmpeg', fps=20)
    plt.close(fig)
