import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

import irmlib.heightmap_generation_testing as hgt   #handles the generation and testing of time-evolving height maps.
import irmlib.irm_image_generation as iig           # handles the conversion of height maps into simulated IRM images.

from scipy.special import jv
import cv2
import os

current_dir = os.path.dirname(os.path.abspath(__file__))   #absolute path of the directory where this script is 

##########           CREATE HEIGHTMAP SERIES         #########

xd=0.128; # camera pixel size in micrometer
(X,Y,height_map_store)=hgt.generate_thermal_fluc_heightmap_testdata(
                          xd=xd,num_of_pixels=331,                    # The height map size (331x331 pixels)
                          colored_spectrum_function=lambda Q: 1/Q**2, # desired power spectrum
                          dt=10,                                      # Time step between frames
                          time_evolution_function=lambda q: 50/q,     # relaxation time tau(q), same unit as dt
                          stabilization_time_frame=150, num_frames=50,
                          amplitude_scaling=50, 
                          equilibrium_height_profile=lambda x,y: (0.0007*x+0.0005*y)*8+0.150,
                          saveas=os.path.join(current_dir,"datasets","height_map_evolution_array.npy"),
                          #video_saveas=os.path.join(current_dir,"datasets","video.mp4"),
                          show_progress=True)
num_of_pixels=height_map_store.shape[1];
hgt.plot_power_spectrum_2D(height_map_store,xd=xd)




##########           CREATE INTERFERENCE MICROSCOPY (IRM) IMAGES         #########

illumination_green=4600; stray_light_green=400;           # Illumination intensity and stray light intensity for green channel
illumination_red  =1900; stray_light_red  =200;           # Illumination intensity and stray light intensity for red channel
psf_kernel_red=  iig.PSF(lambda_=0.660, NA=0.6, xd=xd, size_scaled=6)   # Point Spread Function (PSF) kernel for each color.
psf_kernel_green=iig.PSF(lambda_=0.560, NA=0.6, xd=xd, size_scaled=6)

# mask to simulate the octagonal border of field diaphragm
fov_mask = cv2.imread(os.path.join(current_dir,'datasets','fov_mask.tif'), cv2.IMREAD_GRAYSCALE)
fov_mask = cv2.resize(fov_mask, height_map_store[:,:,1].shape, interpolation=cv2.INTER_LINEAR)
# adding effect of uneven lighting from the lamp.
illum_imhomogenity=cv2.imread(os.path.join(current_dir,'datasets','illumination_inhomogeniety.tif'), cv2.IMREAD_UNCHANGED)
illum_imhomogenity = cv2.resize(illum_imhomogenity, height_map_store[:,:,1].shape, interpolation=cv2.INTER_LINEAR)

for i in range(height_map_store.shape[-1]):
    # Convert the height map into an ideal IRM intensity image for each color channel.
    IRM_intensity_red=  iig.height_to_IRM_intensity(illumination_red, height_map_store[:,:,i],           # This function models the physics of interference
                                                    del_h=0.12832,I_mod=0.521, I_mid=1.045, h_avg=0)     # to transform height map to intensity map
    IRM_intensity_green=iig.height_to_IRM_intensity(illumination_green, height_map_store[:,:,i], 
                                                    del_h=0.11064,I_mod=0.126, I_mid=1.027, h_avg=-0.020)
    
    IRM_intensity_red_after_microscopy=iig.microscopy_effect_on_IRM_intenisty_map(IRM_intensity_red,    # this function incorporates the effect of microscopy
                                        fov_mask=fov_mask, illum_imhomogenity=illum_imhomogenity,       # on the intenisty map
                                        psf_kernel=psf_kernel_red,stray_light= stray_light_red, shot_noise=True )
    IRM_intensity_green_after_microscopy=iig.microscopy_effect_on_IRM_intenisty_map(IRM_intensity_green, 
                                        fov_mask=fov_mask, illum_imhomogenity=illum_imhomogenity,
                                        psf_kernel=psf_kernel_green,
                                        stray_light= stray_light_green, shot_noise=True )
    embeded_image=iig.embed_in_a_rectangular_frame(IRM_intensity_green_after_microscopy,                # this function embeds intenisty map of two channel 
                                                   IRM_intensity_red_after_microscopy,                  # into a single image, simulating the effect of optosplit instrument
                                                   split=0.07, border=0.03, camera_offset=100)
    cv2.imwrite(os.path.join(current_dir,"datasets","test_IRM_image_series",f"IRM{str(i).zfill(6)}.png"), embeded_image.astype(np.uint16))


##########           CREATE BACKGROUND IMAGES         #########

for i in range(50):
    BKG_intensity_red_after_microscopy=iig.microscopy_effect_on_IRM_intenisty_map(                           # to find background intensity
                                                  illumination_red*np.ones(height_map_store[:,:,1].shape),   # passing uniform illumination as intensity map
                                                  fov_mask=fov_mask, illum_imhomogenity=illum_imhomogenity,  # and applying miscroscopy effects
                                                  psf_kernel=psf_kernel_red, stray_light= stray_light_red, shot_noise=True )
    BKG_intensity_green_after_microscopy=iig.microscopy_effect_on_IRM_intenisty_map(
                                                  illumination_green*np.ones(height_map_store[:,:,1].shape), 
                                                  fov_mask=fov_mask, illum_imhomogenity=illum_imhomogenity,
                                                  psf_kernel=psf_kernel_green, stray_light= stray_light_green, shot_noise=True )
    
    embeded_image=iig.embed_in_a_rectangular_frame(BKG_intensity_green_after_microscopy, BKG_intensity_red_after_microscopy, 
                                                   split=0.07, border=0.03, camera_offset=100)
    cv2.imwrite(os.path.join(current_dir,"datasets","test_BKG_images",f"BKG{str(i).zfill(6)}.png"), embeded_image.astype(np.uint16))
