"""
This file contains classes necessary to create the gui elements of the lissajous viewer 
window (third window) and implement their functionalities.
"""

# importing libraries
import tkinter as tk

import random

import numpy as np

import PIL, cv2
from matplotlib.figure import Figure
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

import threading, queue

import utils.gui_utils as guiutil        # utility functions for GUI widget creation and updating
import utils.cv_utils as cvutil          # utility functions for image processing 
import utils.lissajous_utils as lissutil # Utility funcitons for lissajous plot creation and fitting
import utils.constants as c              # Contains constants related to interference microscopy instrumentation

import utils.help_button_content as hlp  # Contains constants that are shown when user clicks help button

class LissajousWindow:
    def __init__(self, root3, appstate):
        """Initializes all components and state variables."""
        self.appstate=appstate                 # appstate stores important data from past windows.
        self.root3 = root3                     # root3-> current window
        self.slider_pos=0;                     # slider position initialized to 0
        self.is_drawing = False;               # tracks if user is drawing ROI on canvas, initalized to false
        self.is_regstn_button_clicked=False    # tracks if user has pressed the "register" button yet, intialized to false
        self.liss_smooth=0.0001                # Smoothing parameter for lissajour plot
        # `shift_by` -> how much the right-side image must be shifted to align with the left side
        self.shift_by=cvutil.calculate_shift_needed_for_registration(self.appstate.FOV_mask,self.appstate.split_position)
        self.comm_queue = queue.Queue()        # Queue for handling threaded operations
        self.create_widgets()

    def create_widgets(self):
        """ 
        Populates the Lissajous analysis window with widgets and frames.

        `left_frame`: this frame contains Image registration, ROI drawing, and Lissajous fitting controls.
            - `controls_frame1`: Checkboxes (`l_cb` and `r_cb` (corresponding to left and right sides))
                               to toggle display of either sides, or both sides overlapped.
                               These checkboxes are Used to visually check image alignment before/after registration.
            - `canvas`: Displays the images
            - `controls_frame2`: `slider` and `slider_label` to navigate through image stack.
            - `controls_frame3`: Textbox for entering smoothing parameter, that is used in Lissajous fitting.
            - `controls_frame4`: contains the following Buttons
                - `regstn_button`: clicking this button auto-aligns left/right sides using phase correlation registration method.
                - `roi_button`: clicking this button lets the user draw a region of interest on the `canvas` widget
                - `lissajous_button`: clicking this button computes Lissajous plot from selected ROI
                                      and fits the empirical Lissajous curve equation.
            - `controls_frame5`: contains `fitting_log` that displays progress logs of lissajour fitting.

        `right_frame`: this frame contains the following widget
            - `canvas2`: Displays the Lissajous plot inserted into matplotlib `fig` object
            - 'Next' button: navigation to go to next window.
        """
        top_frame=guiutil.create_frame(parent=self.root3, expand=True, fill=tk.BOTH)
        help_next_button_container=guiutil.create_frame(parent=self.root3, expand=False, fill=tk.BOTH)
        #-----------------------------------------------------------------------------------------
        left_outer_frame=guiutil.create_toplevel_container(parent=top_frame,side=tk.LEFT)
        left_frame_border=guiutil.create_bordered_frame(parent=left_outer_frame, fill=tk.BOTH, expand=True)
        self.left_frame=guiutil.create_toplevel_container(parent=left_frame_border)
        #-----------------------------------------------------------------------------------------
        self.controls_frame1=guiutil.create_frame(parent=self.left_frame)
        self.lr1_label=guiutil.create_label(text="Show side:", parent=self.controls_frame1)
        self.l_cb , self.l_var=guiutil.create_cb(to_function=self.show_image, text="Left",
                                                 parent=self.controls_frame1)
        self.r_cb , self.r_var=guiutil.create_cb(to_function=self.show_image, text="Right",
                                                 parent=self.controls_frame1)
        #-----------------------------------------------------------------------------------------
        self.canvas=guiutil.create_canvas(self.left_frame)
        self.canvas.bind("<Configure>", self.center_image)  # when canvas updates, center_image function is called and the image gets centered automatically
        #-----------------------------------------------------------------------------------------
        self.controls_frame2=guiutil.create_frame(parent=self.left_frame)
        self.slider_label_var = tk.StringVar(); 
        guiutil.update_slider_label(self.slider_label_var, self.slider_pos, self.appstate.irm_image_files)
        self.slider_label =guiutil.create_label(textvariable=self.slider_label_var, 
                                                parent=self.controls_frame2)
        self.slider=guiutil.create_slider(from_=0, to=max(0, len(self.appstate.irm_image_files)-1), 
                                          to_function=self.update_image_from_slider, 
                                          parent=self.controls_frame2)
        #-----------------------------------------------------------------------------------------
        self.controls_frame3=guiutil.create_frame(parent=self.left_frame)
        self.smoothing_tb, self.smoothing_tb_var=guiutil.create_tb(function_binding=self.update_liss_smooth,
                                                                   bound_how="<Return>", 
                                                                   init_txt=str(self.liss_smooth),
                                                                   side=tk.RIGHT, parent= self.controls_frame3, width=9)
        self.smoothing_label=guiutil.create_label(text="Smoothing (pixels)",
                                                  side=tk.RIGHT, parent=self.controls_frame3)
        #-----------------------------------------------------------------------------------------
        self.controls_frame4=guiutil.create_frame(parent=self.left_frame)
        self.lissajous_button=guiutil.create_button(text="Calculate and Fit Lissajous Plot", 
                                                    to_function=self.plot_lissajous, 
                                                    side=tk.RIGHT, parent=self.controls_frame4)
        self.roi_button=guiutil.create_button(text="Draw ROI", to_function=self.roi_button_response, 
                                              side=tk.RIGHT, parent=self.controls_frame4, width=15)
        self.regstn_button=guiutil.create_button(text="Perform Registration", 
                                                 to_function=self.regstn_button_response, 
                                                 side=tk.RIGHT, parent=self.controls_frame4)
        #-----------------------------------------------------------------------------------------
        self.controls_frame5=guiutil.create_frame(parent=self.left_frame)
        self.fitting_log=guiutil.create_label(text="",side=tk.RIGHT, parent=self.controls_frame5)

        #==========================================================================================

        right_outer_frame=guiutil.create_toplevel_container(parent=top_frame,side=tk.LEFT)
        right_frame_border=guiutil.create_bordered_frame(parent=right_outer_frame, fill=tk.BOTH, expand=True)
        self.right_frame=guiutil.create_toplevel_container(parent=right_frame_border)
        #-----------------------------------------------------------------------------------------
        self.fig = Figure(figsize=(3, 3), dpi=100, facecolor='#1C1C1C')
        self.canvas2 = FigureCanvasTkAgg(self.fig, master=self.right_frame)   # FigureCanvasTkAgg integrates Matplotlib figures into Tkinter gui
        self.canvas2.get_tk_widget().pack(side=tk.TOP, fill=tk.BOTH, expand=1)
        #-----------------------------------------------------------------------------------------
        self.next_button = guiutil.create_button(text="Next >>", 
                                                 to_function=lambda: None, side=tk.RIGHT, parent=help_next_button_container)
        guiutil.create_button(text="?", to_function=hlp.show_help_liss_window,
                              side=tk.LEFT,  width=1, parent=help_next_button_container)
        guiutil.change_state_of_elements(disable=[self.roi_button, self.lissajous_button, 
                                                  self.smoothing_tb, self.smoothing_label, self.next_button ], 
                                         set_true=[self.l_var, self.r_var])
        self.show_image()

    ###############################################################################################

    def update_image_from_slider(self, val):
        """
        Triggered by `slider` widget movement; updates `slider` related variables, `slider_label` 
        widget, and updates image in `canvas` widget.
        """
        self.slider_pos = int(float(val)); 
        self.show_image()
        guiutil.update_slider_label(self.slider_label_var, self.slider_pos, self.appstate.irm_image_files)


    def update_liss_smooth(self, event):
        """
        Updates `liss_smooth` variable from user input in `smoothing_tb` textbox widget; 
        update_vars_from_tb_input function enforces a minimum `liss_smooth` of 0.0001, and maximum of image size/24.
        """
        self.liss_smooth=guiutil.update_vars_from_tb_input(textbox='liss_smooth', 
                                                           vars_to_update=self.liss_smooth,
                                                           other_inputs=(self.smoothing_tb_var, self.img))
        self.smoothing_tb_var.set(str(self.liss_smooth))
        self.root3.focus_set()                        # focus out of the textbox

    def regstn_button_response(self):
        """
        Updates image in `canvas` widget with registered (aligned) version of left and right image.
        """
        self.is_regstn_button_clicked=True  # leads to show_image function updating the image with registered image
        self.show_image()
        guiutil.change_state_of_elements(disable=[self.regstn_button], 
                                         enable=[self.roi_button])

    #----------------------------------------------------------------------------------------------

    def roi_button_response(self):
        """
        This function is triggered by pressing the `roi_button`. 
         - If the user wasn't drawing on `canvas` already (`is_drawing` = False), 
              - this function activates the canvas for drawing points to create a polygonal ROI, 
              - inactivates `roi_button` to prevent it from being clicked
              - deletes any previously drawn `roi_points` from canvas and memory. 
              - The left click of mouse is bound to the function `add_roi_points` that sequentially 
                adds (x,y) position of user's mouse clicks on canvas in the `roi_points` variable.
         - After user has drawn atleast 3 points (enough for a ROI), `add_roi_points` will enable the 
           `roi_button` for clicks
         - If user clicked this button while user was drawing ROI (`is_drawing` = True)
              - sets `is_drawing` to False to end the drawing.
        """
        if self.is_drawing==False:
            guiutil.change_state_of_elements(disable=[self.lissajous_button, self.smoothing_tb, 
                                                      self.smoothing_label, self.next_button])
            self.fitting_log.config(text="")
            self.is_drawing = True
            self.roi_points = []
            # disables the buttona nd changes the roi_button name to alert user that they need to draw mode than two points to make a roi
            self.roi_button.config(text="Add >2 pts", state=tk.DISABLED) 
            self.canvas.bind("<Button-1>", self.add_roi_point) # left click binds to add_roi_point function
        else:
            self.is_drawing = False    
            self.roi_button.config(text="Redraw ROI", state=tk.NORMAL)
            self.roi_points.append(self.roi_points[0])
            guiutil.change_state_of_elements(enable= [self.lissajous_button,  self.smoothing_tb, 
                                                      self.smoothing_label])
        self.show_image()

    def add_roi_point(self, event):
        """
         - Converts left-clicks location in `canvas` coordinates into pixel location in image 
           coordinates (x,y tuple) using map_clicks_on_canvas_to_image_coordinate function, and adds this to 
           `roi_points` variable (list of tuple).   
         - Also changes the `roi_button` state when atleast 3 points have been drawn.
        """
        if self.is_drawing:
            selected_pt= guiutil.map_clicks_on_canvas_to_image_coordinate(self.canvas, self.canvas_image_id, 
                                                                          canvas_image=self.tk_image, 
                                                                          original_image=self.img, 
                                                                          canvas_coords_of_click=event)
            if selected_pt: 
                self.roi_points.append(selected_pt)
            # if atleast three roi points have been added by user, `roi_button` text changes to 
            # `finish drawing` and becomes enabled. Clicking roi button after this will end the drawing.
            if len(self.roi_points)>2:
                self.roi_button.config(text="Finish Drawing", state=tk.NORMAL)
            self.show_image()

###################################################################################################

    def show_image(self):
        """
        This function updates images on `canvas` widget.

         - If `regstn_button` is not clicked yet: 
             - image is split at `split_position`, and left and right side is overlayed with appropriate colors. 
         - If  `regstn_button` is clocked:
             - Image is split, right side image is shifted to align them, and then overlayed.
             - If `roi_points` attribute has been created:
                 - roi region is shown on the canvas
        """
        self.img = cv2.imread(self.appstate.irm_image_files[self.slider_pos], cv2.IMREAD_UNCHANGED).astype(np.uint16)
        if self.is_regstn_button_clicked:
            self.img=cvutil.split_and_overlay(self.img,self.appstate.FOV_mask,self.appstate.split_position, #left and right color is set to [0,0,0]
                                               shift_by=self.shift_by,                             #when l_cb and r_cb checbox si unchecked
                                               left_color=c.left_color*self.l_var.get(),           # so that the image becomes cblack
                                               right_color=c.right_color*self.r_var.get())         # so that in overlay that side image doesnt show up
            if hasattr(self, "roi_points") and ((self.is_drawing) or (len(self.roi_points)>0)):    
                self.img=cvutil.overlay_roi(self.img,self.roi_points)
        else:
            self.img=cvutil.split_and_overlay(self.img,self.appstate.FOV_mask,self.appstate.split_position, 
                                               shift_by=None,
                                               left_color=c.left_color*self.l_var.get(),
                                               right_color=c.right_color*self.r_var.get())
        self.tk_image= cvutil.get_formatted_image(self.img,255, 0)
        self.canvas.delete("all")
        self.canvas_image_id = self.canvas.create_image(0, 0, image=self.tk_image)
        self.center_image()

    def center_image(self, event=None):
        """
        Recenters the image on canvas, every time canvas is updated
        """
        self.canvas.coords(self.canvas_image_id,self.canvas.winfo_width() / 2, self.canvas.winfo_height() / 2)
        self.canvas.itemconfig(self.canvas_image_id, anchor='center')

###################################################################################################

    def update_plot(self, data=None, fitcurve=None):
        """
        Clears the figure on the right side canvas, shows the scatter plot of experimental Lissajous plot 
        (defined as normalized intensity of a pixel at wavelength1 (left side image), vs. normalized 
        intensity of the same pixel at wavelength2 (right side image)). If fitting is being performed, 
        the fitted Lissajous curve is also shown on the figure as a line plot.
        """
        self.fig.clf()
        self.ax = self.fig.add_subplot(111,  facecolor='#1C1C1C')
        plot_color = 'lightgray'

        self.ax.scatter(data[0], data[1], color='#4467F5', s=6, alpha=0.2)
        if fitcurve:
            Ith_left=fitcurve[0]; Ith_right=fitcurve[1]
            self.ax.plot(Ith_left, Ith_right, color=plot_color, linewidth=3)
        self.ax.set_xlabel("$I^R_{left}$", color=plot_color); self.ax.set_ylabel("$I^R_{right}$", color=plot_color)
        self.ax.tick_params(axis='both', colors=plot_color)
        for spine in self.ax.spines.values():
            spine.set_edgecolor(plot_color)
        self.canvas2.draw()

    def plot_lissajous(self):
        """
        Extracts intensity pairs from the ROI region for experimental Lissajous plot, 
        starts the fitting in a separate thread, and begins polling the queue for results.
        """

        guiutil.change_state_of_elements(disable=[self.roi_button, self.lissajous_button, 
                                                  self.smoothing_tb, self.smoothing_label, self.next_button ])

        self.liss_tofit=lissutil.get_intensity_pairs_from_roi(self.appstate.irm_image_files, self.appstate.avg_bkg_image, 
                                                              self.appstate.split_position, self.shift_by, 
                                                              self.liss_smooth,
                                                              self.appstate.left_stray_light, self.appstate.right_stray_light, 
                                                              self.roi_points)
        self.update_plot(data=self.liss_tofit)
        self.worker_thread = threading.Thread(
            target=lissutil.fit_lissajous,
            args=(self.liss_tofit, c.delh_left, c.delh_right, self.comm_queue)
        )
        self.worker_thread.start()
        self.check_queue()

    def check_queue(self):
        """
        Checks the communication queue for messages from the worker thread.
        This method drains the entire queue on each call, processing all
        pending messages in a batch.
        """
        try:
            while True:             # Loop continuously to get all messages currently in the queue
                message = self.comm_queue.get(block=False)  # Check for message, without waiting for it to arrive.
                if isinstance(message, str):                # string messages are logs of progress of lissajous plot fitting 
                    self.fitting_log.config(text=message);  # update `fitting_log` widget
                    print(message) 
                    if message == "Gradient Descent Finished.":  # if fitting has finished
                        guiutil.change_state_of_elements(enable=[self.lissajous_button, self.next_button, 
                                                                 self.roi_button,self.smoothing_tb, self.smoothing_label])
                elif isinstance(message, dict): # when intermediate or final fit result is sent as a dictionary, update the plot
                    (self.x, self.fit_params) = (message['x'], message['fit_params'])
                    Ith_left, Ith_right = lissutil.get_fit_plot(self.x, self.fit_params, c.delh_left, c.delh_right)
                    self.update_plot(data=self.liss_tofit, fitcurve=[Ith_left, Ith_right])
        except queue.Empty:  # when the queue is empty, do nothing
            pass
        self.root3.after(30, self.check_queue) # schedule the next queue check 30 ms later


