"""
This file contains classes necessary to create the gui elements of the Height map viewer 
window (Fourth window) and implement their functionalities.
"""

# importing libraries
import tkinter as tk
import matplotlib # Import matplotlib
import random

import numpy as np

import PIL, cv2
from matplotlib.figure import Figure
# Explicitly import the Agg canvas for reliability in multiprocessing
from matplotlib.backends.backend_agg import FigureCanvasAgg as FigureCanvas
from concurrent.futures import ProcessPoolExecutor
from concurrent.futures import ThreadPoolExecutor

import threading, queue
import multiprocessing


import utils.gui_utils as guiutil
import utils.cv_utils as cvutil
import utils.lissajous_utils as lissutil
import utils.constants as c

import utils.help_button_content as hlp
import pickle
import os


import time

# to do:
# then, hole closure
# threading to stop gui from not responding
# embed the plots. link slider to plot updates

# enable save and close after wards and disable save and close afte rredrawing has started
# x data is not proper rigth now
# check if pickle is ok

# =====================================================================================
# INITIALIZER FOR THE PROCESS POOL
# This setup is critical for performance by preventing repeated Matplotlib setup.
# =====================================================================================


FIG = None
AX1 = None
AX2 = None

def init_worker():
    """
    This function runs once per worker process. It forces the 'Agg' backend,
    ensuring a renderable canvas is created without needing a GUI.
    """
    global FIG, AX1, AX2
    import matplotlib
    matplotlib.use('Agg')  # Safe for multiprocessing, no GUI required

    from matplotlib.figure import Figure
    from matplotlib.backends.backend_agg import FigureCanvasAgg as FigureCanvas

    FIG = Figure(figsize=(4.5, 7), dpi=60, facecolor='#1C1C1C') #4.5 7
    FigureCanvas(FIG)

    # Two vertically stacked subplots
    AX1 = FIG.add_subplot(211, facecolor='#1C1C1C')
    AX2 = FIG.add_subplot(212, facecolor='#1C1C1C')

    # Remove all ticks and labels (since you'll manually control later)
    for a in (AX1, AX2):
        a.set_xticks([])
        a.set_yticks([])
        for spine in a.spines.values():
            spine.set_visible(False)
        a.set_xlabel("")
        a.set_ylabel("")

# =====================================================================================


def process_and_plot_image(k, image_file, split_position, shift_by,
                           left_stray_light, right_stray_light,
                           left_bkg_image, right_bkg_image,
                           i_frm, i_to, j_frm, j_to,
                           fit_params, Ith_left, Ith_right, xrange):
    """
    This function is executed by each worker process. It performs calculations,
    generates a plot, and RETURNS the plot as an in-memory image array, with timing checks.
    """
    global FIG, AX1, AX2 # Use the pre-initialized Figure and Axes for this process
    AX1.clear()
    AX2.clear()
    plot_color = 'lightgray'

    image = cv2.imread(image_file, cv2.IMREAD_UNCHANGED).astype(np.uint16)
    left_image, right_image = cvutil.split_image(image, split_position)
    left_image, right_image = cvutil.match_image_size(left_image, right_image)

    right_image = cv2.warpAffine(
        right_image, shift_by,
        (left_image.shape[1], left_image.shape[0])
    ).astype(np.uint16)

    left_img_norm = (left_image.astype(np.float32) - left_stray_light) / \
                    (left_bkg_image.astype(np.float32) - left_stray_light)
    right_img_norm = (right_image.astype(np.float32) - right_stray_light) / \
                     (right_bkg_image.astype(np.float32) - right_stray_light)
    left_img_norm = np.ravel(left_img_norm[i_frm:i_to, j_frm:j_to])
    right_img_norm = np.ravel(right_img_norm[i_frm:i_to, j_frm:j_to])

    x_fine = np.arange(xrange[0], xrange[1], 0.001, dtype=np.float32)
    Ith_left_fine, Ith_right_fine = lissutil.get_fit_plot(x_fine, fit_params, c.delh_left, c.delh_right)
    Ith_left_fine=Ith_left_fine.reshape(1,-1)
    Ith_right_fine=Ith_right_fine.reshape(1,-1)
    left_img_norm=left_img_norm.reshape(-1,1)
    right_img_norm=right_img_norm.reshape(-1,1)
    idx=np.argmin(np.square(Ith_left_fine-left_img_norm)+np.square(Ith_right_fine-right_img_norm), axis=1)
    x_calc=x_fine[idx]
    x_calc_2d = x_calc.reshape(i_to - i_frm, j_to - j_frm)
    
    if len(left_img_norm) > 1000:
        idx = random.choices(range(len(left_img_norm)), k=1000)
        left_img_norm_samp = left_img_norm[idx]
        right_img_norm_samp = right_img_norm[idx]
    else:
        left_img_norm_samp = left_img_norm
        right_img_norm_samp = right_img_norm

    AX1.scatter(left_img_norm_samp, right_img_norm_samp, color='#4467F5', s=6, rasterized=True) 
    AX1.plot(Ith_left, Ith_right, color=plot_color, linewidth=3) 
    AX1.set_xlim([(fit_params[0] - 1.3 * fit_params[1]), (fit_params[0] + 1.3 * fit_params[1])])
    AX1.set_ylim([(fit_params[2] - 1.3 * fit_params[3]), (fit_params[2] + 1.3 * fit_params[3])])
    AX1.set_xticks([])
    AX1.set_yticks([])
    im=AX2.imshow(x_calc_2d,
                   cmap='inferno', interpolation='bicubic', vmin=xrange[0], vmax=xrange[1])
    cbar = FIG.colorbar(im, ax=AX2)
    cbar.set_ticks([xrange[0], xrange[1]])
    cbar.set_ticklabels([f'{xrange[0]:.3f}', f'{xrange[1]:.3f}'])
    cbar.ax.tick_params(color=plot_color, labelcolor=plot_color)
    cbar.outline.set_edgecolor(plot_color)
    AX2.set_xticks([])
    AX2.set_yticks([])
    AX2.axis('off')
    
    FIG.canvas.draw()
    # Get the raw buffer and convert it to a numpy array.
    buf = FIG.canvas.buffer_rgba()
    img_array = np.asarray(buf)
    img_bgr = cv2.cvtColor(img_array, cv2.COLOR_RGBA2BGR)
    cv2.imwrite(f"utils/temp_storage/output_{k:03d}.jpg", img_bgr)
    cbar.remove()
    print(x_calc_2d)

    return (k,x_calc_2d)

class HeightmapWindow :
    def __init__(self, root4, appstate):
        """Initializes all components and state variables."""
        self.appstate=appstate
        self.root4 = root4
        self.slider_pos=0;
        self.is_drawing = False;
        os.makedirs("utils/temp_storage", exist_ok=True)
        self.create_widgets()

    def create_widgets(self):
        top_frame=guiutil.create_frame(parent=self.root4, expand=True, fill=tk.BOTH)
        help_next_button_container=guiutil.create_frame(parent=self.root4, expand=False, fill=tk.BOTH)
        #-----------------------------------------------------------------------------------------
        left_outer_frame=guiutil.create_toplevel_container(parent=top_frame,side=tk.LEFT)
        left_frame_border=guiutil.create_bordered_frame(parent=left_outer_frame, fill=tk.BOTH, expand=True)
        self.left_frame=guiutil.create_toplevel_container(parent=left_frame_border)
        #-----------------------------------------------------------------------------------------
        self.controls_frame1=guiutil.create_frame(parent=self.left_frame)
        self.lr1_label=guiutil.create_label(text="Show side:", parent=self.controls_frame1)
        self.l_cb , self.l_var=guiutil.create_cb(to_function=self.show_image, text="Left",
                                                 parent=self.controls_frame1)
        self.r_cb , self.r_var=guiutil.create_cb(to_function=self.show_image, text="Right",
                                                 parent=self.controls_frame1)
        #-----------------------------------------------------------------------------------------
        self.canvas=guiutil.create_canvas(self.left_frame)
        self.canvas.bind("<Configure>", self.center_image)
        #-----------------------------------------------------------------------------------------
        self.controls_frame2=guiutil.create_frame(parent=self.left_frame)
        self.slider_label_var = tk.StringVar(); 
        guiutil.update_slider_label(self.slider_label_var, self.slider_pos, self.appstate.irm_image_files)
        self.slider_label =guiutil.create_label(textvariable=self.slider_label_var, 
                                                parent=self.controls_frame2)
        self.slider=guiutil.create_slider(from_=0, to=max(0, len(self.appstate.irm_image_files)-1), 
                                          to_function=self.update_image_from_slider, 
                                          parent=self.controls_frame2)
        #-----------------------------------------------------------------------------------------
        self.controls_frame4=guiutil.create_frame(parent=self.left_frame)
        self.heightmap_button=guiutil.create_button(text="Calculate heightmap", 
                                                    to_function= self.heightmap_button_response, 
                                                    side=tk.RIGHT, parent=self.controls_frame4, width=19)
        self.roi_button=guiutil.create_button(text="Draw Square ROI", to_function= self.roi_button_response, 
                                              side=tk.RIGHT, parent=self.controls_frame4, width=19)
        #==========================================================================================
        right_outer_frame=guiutil.create_toplevel_container(parent=top_frame,side=tk.LEFT)
        right_frame_border=guiutil.create_bordered_frame(parent=right_outer_frame, fill=tk.BOTH, expand=True)
        self.right_frame=guiutil.create_toplevel_container(parent=right_frame_border)
        #-----------------------------------------------------------------------------------------

        self.close_button = guiutil.create_button(text="Save Data and Close", 
                                                 to_function=self.close_button_response, side=tk.RIGHT, parent=help_next_button_container)
        guiutil.create_button(text="?", to_function=hlp.show_help_liss_window,
                              side=tk.LEFT,  width=1, parent=help_next_button_container)
        guiutil.change_state_of_elements(disable=[ self.heightmap_button, 
                                                  self.close_button ], 
                                         set_true=[self.l_var, self.r_var])
        self.show_image()

    def close_button_response(self):
        with open("utils/temp_storage/heightmap_results.pkl", "wb") as f:
            pickle.dump(self.in_memory_results, f)
        self.root4.destroy()


    def heightmap_button_response(self):
        self.heightmap_button.config(text="Calculating...")
        self.root4.update_idletasks()

        # --- Data Preparation ---
        Ith_left, Ith_right = lissutil.get_fit_plot(self.appstate.x, self.appstate.fit_params, c.delh_left, c.delh_right)
        left_bkg_image, right_bkg_image = cvutil.split_image(self.appstate.avg_bkg_image, self.appstate.split_position)
        left_bkg_image, right_bkg_image = cvutil.match_image_size(left_bkg_image, right_bkg_image)
        right_bkg_image = cv2.warpAffine(right_bkg_image, self.appstate.shift_by,
                                         (left_bkg_image.shape[1], left_bkg_image.shape[0])).astype(np.uint16)
        j = (self.square_roi_points[0][0], self.square_roi_points[1][0])
        j_frm, j_to = min(j), max(j)
        i = (self.square_roi_points[0][1], self.square_roi_points[1][1])
        i_frm, i_to = min(i), max(i)
        xrange = (round(float(np.min(self.appstate.x)), 3),
                  round(float(np.max(self.appstate.x)), 3))
        print(xrange)
        time.sleep(10)
        
        tasks = []
        for k in range(len(self.appstate.irm_image_files)):
            tasks.append((
                k, self.appstate.irm_image_files[k], self.appstate.split_position, self.appstate.shift_by,
                self.appstate.left_stray_light, self.appstate.right_stray_light,
                left_bkg_image, right_bkg_image,
                i_frm, i_to, j_frm, j_to,
                self.appstate.fit_params, Ith_left, Ith_right, xrange
            ))
        
        print("Starting processing... GUI will be unresponsive.")
        results_list = []
        with multiprocessing.Pool(initializer=init_worker) as pool:
            # starmap blocks until all results are ready and returns them as a list.
            results_list = pool.starmap(process_and_plot_image, tasks)
        self.in_memory_results = dict(results_list)
        self.heightmap_button.config(text="Calculate heightmap")
        
    def update_image_from_slider(self, val):
        self.slider_pos = int(float(val)); 
        self.show_image()
        guiutil.update_slider_label(self.slider_label_var, self.slider_pos, self.appstate.irm_image_files)

    def roi_button_response(self):
        self.square_roi_points = []
        self.roi_button.config(text="Click 2 diagonal corners") 
        guiutil.change_state_of_elements(disable=[self.close_button, self.roi_button])
        self.canvas.bind("<Button-1>", self.add_roi_point)
        self.canvas.bind("<Motion>", self.on_mouse_move)
        self.show_image()

    def add_roi_point(self, event):
        selected_pt= guiutil.map_clicks_on_canvas_to_image_coordinate(self.canvas, self.canvas_image_id, 
                                                                        canvas_image=self.tk_image, 
                                                                        original_image=self.img, 
                                                                        canvas_coords_of_click=event)
        if selected_pt: 
            self.square_roi_points.append(selected_pt)
            if len(self.square_roi_points) == 2:
                self.canvas.unbind("<Button-1>"); self.canvas.unbind("<Motion>")
                self.roi_button.config(text="Redraw Square ROI")
                if hasattr(self, "mouse_motion"):
                    del self.mouse_motion
                guiutil.change_state_of_elements(enable=[self.roi_button, self.heightmap_button])
            self.show_image()
            
    def on_mouse_move(self, event):
        if len(self.square_roi_points) == 1:
            self.mouse_motion= guiutil.map_clicks_on_canvas_to_image_coordinate(self.canvas, self.canvas_image_id, 
                                                                            canvas_image=self.tk_image, 
                                                                            original_image=self.img, 
                                                                            canvas_coords_of_click=event)
            self.show_image()


    def show_image(self):
        self.img = cv2.imread(self.appstate.irm_image_files[self.slider_pos], cv2.IMREAD_UNCHANGED).astype(np.uint16)
        self.img=cvutil.split_and_overlay(self.img,self.appstate.FOV_mask,self.appstate.split_position,
                                            shift_by=self.appstate.shift_by,
                                            left_color=c.left_color*self.l_var.get(),
                                            right_color=c.right_color*self.r_var.get())         
        self.img=cvutil.overlay_filled_roi(self.img,self.appstate.roi_points)
        if hasattr(self, "square_roi_points"):
            if len(self.square_roi_points)==1:
                self.img=cvutil.overlay_roi(self.img,self.square_roi_points)
            if len(self.square_roi_points)==2:
                rect_start=self.square_roi_points[0]
                rect_end=self.square_roi_points[1]
                self.img=cvutil.overlay_roi(self.img,[rect_start, (rect_end[0], rect_start[1]), rect_end, (rect_start[0], rect_end[1]), rect_start])
        if hasattr(self, "mouse_motion") and len(self.square_roi_points)==1:
            rect_start=self.square_roi_points[0]
            rect_end=self.mouse_motion
            self.img=cvutil.overlay_roi(self.img,[rect_start, (rect_end[0], rect_start[1]), rect_end, (rect_start[0], rect_end[1]), rect_start])

        self.tk_image= cvutil.get_formatted_image(self.img,255, 0)
        self.canvas.delete("all")
        self.canvas_image_id = self.canvas.create_image(0, 0, image=self.tk_image)
        self.center_image()

    def center_image(self, event=None):
        self.canvas.coords(self.canvas_image_id,self.canvas.winfo_width() / 2, self.canvas.winfo_height() / 2)
        self.canvas.itemconfig(self.canvas_image_id, anchor='center')