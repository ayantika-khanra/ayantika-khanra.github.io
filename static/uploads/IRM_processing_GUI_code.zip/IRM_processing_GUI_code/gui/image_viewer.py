"""
This file contains classes necessary to create the gui elements of the image viewer 
window and implement their functionalities.
"""

# importing libraries
import tkinter as tk
import numpy as np
import PIL, cv2
import utils.gui_utils as guiutil        # Contains utility functions for GUI widget creation and updating
import utils.cv_utils as cvutil          # utility functions for image processing 
import utils.help_button_content as hlp  # Contains constants that are shown when user clicks help button

###########   Top half of the window: background image viewer    ###########  

class BKGImageViewer:
    """
    This class contains the content of top-half of the Image Viewer window (first window)
       to view background images. 
    It implements:
      - Folder selection and image loading
      - Scrolling through an image series interactively using a slider
      - Display of an averaged image 
    """
    def __init__(self, parent, loading_status_thisviewer, loading_status_otherviewer, next_button): 
        self.parent = parent;         # container frame spanning top half of the "Image Viewer" window
        self.loading_status_thisviewer= loading_status_thisviewer;      # if folder is loaded and valid, in this viewer 
        self.loading_status_otherviewer= loading_status_otherviewer;    # if folder is loaded and valid, in the other viewer (irm image viewer)
        self.next_button_of_full_window=next_button                     # next button in the master window

        self.current_slider_pos = 0;  # slider position, initialized to 0
        self.create_widgets()         # Populate parent frame with Tkinter widgets

    def create_widgets(self):
        """
        Places all UI components in the parent frame:

        Layout:

         - `folder_frame` : Frame with folder selection controls
             - `load_button`: A button to open folder selection dialog
             - `folder_label`: Displays currently selected folder path or 
                               a placeholder text "No folder selected"

         - `canvas`: Displays either an image from the selected folder, or the average image,
                    depending on the state of the `slider` and `avg_checkbox` widget

         - `controls_frame`: Frame holding the slider, its label, and image averaging checkbox
             - `slider`: Moves through image sequence
             - `slider_pos_label`: shows slider position in the format 
                                   "current image no/ total no of images"
                 - `slider_pos_var`: stores string displayed in `slider_pos_label`
             - `avg_checkbox`: Clicking this checkbox shows the averaged image of the image series.
                               Averaging of background images is important for noise reduction.
                 - `avg_var`: Tracks state of `avg_checkbox` widget
        """
        top_border_frame=guiutil.create_bordered_frame(parent=self.parent, fill=tk.BOTH, expand=True)
        self.top_frame=guiutil.create_toplevel_container(parent=top_border_frame)
        folder_frame=guiutil.create_frame(self.top_frame)

        self.folder_label =guiutil.create_label(text="No folder selected",parent=folder_frame)
        self.load_button=guiutil.create_button(text="Load Background Folder", 
                                               to_function=self.load_folder, 
                                               parent=folder_frame, width=23)

        self.canvas=guiutil.create_canvas(self.top_frame)

        self.controls_frame=guiutil.create_frame(self.top_frame)
        self.slider_label_var = tk.StringVar(); 
        self.slider_label_var.set("0 / 0")
        self.slider_label =guiutil.create_label(textvariable=self.slider_label_var, 
                                                parent=self.controls_frame)
        self.slider=guiutil.create_slider(from_=0, to=0, 
                                          to_function=self.update_image_from_slider, 
                                          parent=self.controls_frame)
        self.avg_checkbox,self.avg_var=guiutil.create_cb(to_function=self.toggle_average, 
                                                         text="Show Average of the Stack",
                                                         side=tk.RIGHT, parent=self.controls_frame)
        guiutil.change_state_of_elements(disable=[self.slider, self.avg_checkbox])


    def load_folder(self):
        """
        Opens a folder selection dialog and loads all valid image files.
        Bound to `load_button` widget. 
        After selection:
         - updates `folder_label` widget 
         - updates slider related widgets
             - sets the min/max range of `slider` widget
             - updates `current_slider_pos` to zero
             - updates`slider_label` wisget by updating `slider_label_var` variable
         - computes the average background image
         - Sets intensity thresholds (`min_intensity_of_bkg`, `min_intensity_of_bkg`) 
           for histogram normalization
         - Displays the initial image
        """

        folder = tk.filedialog.askdirectory(title="Select Image Folder")  # opens a folder selection dialog
        if folder:  
            self.image_files=[] ;
            if hasattr(self, 'avg_image'): del self.avg_image;   
            self.image_files=guiutil.load_filelist(folder)    
            try:
                self.avg_image=cvutil.compute_average_image(file_list=self.image_files)  
            except:
                pass  
            if (len(self.image_files)>0) and hasattr(self, 'avg_image'): #If folder has image files, and image averaging could be performed, folder is valid
                # Store the folder path, list of valid files in it, and updates `folder_label` widget                     
                self.bkg_image_folder = folder               
                self.folder_label.config(text=f"Folder: {guiutil.shorten_folder_path(folder)}")   

                # updates `slider` widget min/max range, slider label, and enables `slider` and 
                # `avg_checkbox` widget for user interaction
                self.slider.config(to=max(0, len(self.image_files)-1))           
                self.current_slider_pos = 0; self.slider.set(0)             
                guiutil.update_slider_label(self.slider_label_var, self.current_slider_pos,
                                            self.image_files, self.avg_var)                    
                guiutil.change_state_of_elements(enable=[self.slider,self.avg_checkbox],            
                                                set_false=[self.avg_var])
                
                # computes average image and sets minimum and maximum intensity thresholds for histogram normalization
                self.min_intensity_of_bkg=0.8*np.min(self.avg_image)         
                self.max_intensity_of_bkg=1.2*np.max(self.avg_image)  

                self.loading_status_thisviewer.set(True)  # folder loading was successful
                self.update_next_button_state()           # enable next button if the other viewer also loaded images successfully

                self.show_image()   # display the image on the canvas.  
            else:       
                #If folder has no image files, or image averaging could not be performed, then folder is invalid
                # and slider is disabled, loading status is set to False, and canvas is cleared
                self.slider.config(to=0)           
                self.current_slider_pos = 0; self.slider.set(0)   
                self.slider_label_var.set("0 / 0")      
                self.folder_label.config(text="")                  
                guiutil.change_state_of_elements(disable=[self.slider,self.avg_checkbox],            
                                                set_false=[self.avg_var])
                self.loading_status_thisviewer.set(False)
                self.update_next_button_state()

                self.canvas.delete("all")

    
    def update_next_button_state(self):
        """
        Enables "Next" button, if both viewer (IRM and BKG viewer) has successfully 
        loaded folders containing image files
        """
        if self.loading_status_thisviewer.get() and self.loading_status_otherviewer.get():
            self.next_button_of_full_window.config(state=tk.NORMAL)
        else:
            self.next_button_of_full_window.config(state=tk.DISABLED)
                                                                                            
    def update_image_from_slider(self, val):
        """
        Updates the displayed image on `canvas` widget, and the `slider_label` widget.
        Bound to `slider` widget.
        
        """
        self.current_slider_pos = int(float(val));  
        guiutil.update_slider_label(self.slider_label_var, self.current_slider_pos, 
                                    self.image_files, self.avg_var)
        self.show_image()                          

    def toggle_average(self):
        """
        Toggles between displaying the averaged image and individual images from selected folder.
         - When `avg_checkbox` is checked, 
             - `slider` is disabled, 
             - `slider` and `slider_label` is updated to "0/0" 
         - When unchecked, 
             - enables `slider`, 
             - restores `slider` and `slider_label` range and to previous values
         - call `show_image` function that either shows `avg_image`, or an image from the folder
        """
        if self.avg_var.get():                                      
            guiutil.change_state_of_elements(disable=[self.slider]) 
            self.slider.config(from_=0, to=0)                       
            guiutil.update_slider_label(self.slider_label_var, self.current_slider_pos, 
                                        self.image_files, self.avg_var)
        else:                                                       
            guiutil.change_state_of_elements(enable=[self.slider])  
            self.slider.config(to=max(0, len(self.image_files) - 1))
            guiutil.update_slider_label(self.slider_label_var, self.current_slider_pos, 
                                        self.image_files, self.avg_var)

        self.show_image()  

    def show_image(self):
        """ 
        Displays the appropriate image (averaged or single frame) on the canvas, depending on the
        state of `avg_checkbox` or the current slider position . 
        Intensity scaling and resizing handled by cvutil.get_formatted_image()
        """
        if self.avg_var.get():                    
            img = self.avg_image                 
        elif self.image_files:                    
            img = cv2.imread(self.image_files[self.current_slider_pos], 
                             cv2.IMREAD_UNCHANGED).astype(np.uint16)
        self.tk_image= cvutil.get_formatted_image(img, self.max_intensity_of_bkg,         
                                                    self.min_intensity_of_bkg, self.canvas)

###########                Bottom half of the window                ###########  
class IRMImageViewer(BKGImageViewer):
    """
    This class contains the content of bottom-half of the Image Viewer window (first window)
      to view interference microscopy images. 
    It inherits all folder-loading and image display logic from `BKGImageViewer`, but:
     - The averaging checkbox is removed, as user doesn't need to examine averaged images. 
     - a "Next" button is added to open the next window (analysis window).
    """
    def __init__(self, parent, loading_status_thisviewer, loading_status_otherviewer, next_button):
        # here this_viewer refers to IRM viewer, and other_viewer refers to BKG viewer 
        super().__init__(parent, loading_status_thisviewer, loading_status_otherviewer, next_button)
        self.avg_checkbox.pack_forget()
        self.load_button.config(text= "Load IRM Folder")


class BKGIRMImageviewer:
    """Class for combining BKGImageViewer, IRMImageViewer class into one window, and add help and next button"""
    def __init__(self, parent):
        self.parent=parent
        # Flags to track if background and irm image series have been loaded
        self.is_bkgseries_loaded=tk.BooleanVar();         self.is_bkgseries_loaded.set(False)
        self.is_irmseries_loaded=tk.BooleanVar();         self.is_irmseries_loaded.set(False)
        self.create_widgets()

    def create_widgets(self):
        bkg_container_frame =guiutil.create_frame(parent=self.parent, expand=True, fill=tk.BOTH)
        irm_container_frame =guiutil.create_frame(parent=self.parent, expand=True, fill=tk.BOTH)
        
        controls_frame =guiutil.create_frame(parent=self.parent, expand=False)
        self.next_button =guiutil.create_button(text="Next >>", 
                                                 to_function=lambda: None,
                                                 side=tk.RIGHT, parent=controls_frame)
        guiutil.change_state_of_elements(disable=[self.next_button])
        help_button =guiutil.create_button(text="?", to_function=hlp.show_help_imviewer_window,
                                                 side=tk.LEFT, parent=controls_frame)

        # below, the first argument is the parent frame where the frame should be placed, 
        # 2nd and 3rd argument is a booleanvar flag to know whether the current type of image (let's say bkg), 
        # and the other type of image series (let's say irm) has been loaded or not. the next button 
        # is also passed so that it can be activated when both image series is loaded (i.e. when both booleanvar is true)                      
        self.irm_viewer = IRMImageViewer(irm_container_frame, self.is_irmseries_loaded, self.is_bkgseries_loaded, self.next_button)
        self.bkg_viewer = BKGImageViewer(bkg_container_frame, self.is_bkgseries_loaded, self.is_irmseries_loaded, self.next_button)
