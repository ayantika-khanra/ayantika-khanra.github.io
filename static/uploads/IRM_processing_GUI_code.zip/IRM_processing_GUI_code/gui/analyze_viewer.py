"""
This file contains classes necessary to create the gui elements of the analyzer 
window (second window) and implement their functionalities.
"""

import tkinter as tk
from tkinter import ttk

import numpy as np

import PIL, cv2

import utils.gui_utils as guiutil     # Contains utility functions for GUI widget creation and updating
import utils.cv_utils as cvutil       # utility functions for image processing 
import utils.constants as c           # Contains constants related to interference microscopy instrumentation
import utils.help_button_content as hlp  # Contains constants that are shown when user clicks help button


class AnalysisWindow:
    def __init__(self, root2, appstate):
        """
        Initializes the Analysis window, components and related variables.
        """
        self.root2 = root2                        # root2 is the Analysis window
        
        # appstate stores important data from past windows.
        # Load the average background image `avg_bkg_image` and a representative IRM image 
        # `rep_irm_image`, and set min/max intensity threshold for histogram normalization
        self.avg_bkg_image = appstate.avg_bkg_image
        self.rep_irm_image = cv2.imread(appstate.irm_image_files[0], 
                                        cv2.IMREAD_UNCHANGED).astype(np.uint16)
        self.max_intensity = appstate.max_intensity_of_bkg; 
        self.min_intensity = appstate.min_intensity_of_bkg;

        # Default split position at middle of the image
        self.split_position = self.avg_bkg_image.shape[1]//2 

        #FOV is the well-lit central part of the image on left and right sides, with octagonal border.
        #A mask for this region is `FOV_mask` based on otsu thresholding. Users can edit eff_FOV_thresh
        #[default is 100 (%)] to increase or decrease the threshold intensity.
        self.eff_fov_thresh=100.0
        self.FOV_mask=cvutil.otsu_thresholding(self.avg_bkg_image, self.split_position,
                                                eff_thresh=self.eff_fov_thresh)
        
        # Auto-detects region illuminated by stray light (region bound by octangonal FOV boundary
        # and rectangular shutter edge), and stray light intensity is calculated in left and right side
        self.autocalculate_straylight()

        self.create_widgets() # creates widgets in the root2 window

###################################################################################################

    def create_widgets(self):
        """
        This function populates the window with the following widgets:

        - `top_frame`: holds the subframes

           - `controls_frame1`: widgets for overlaying IRM image, split location and straylight detection
              - `irm_cb`: Checkbox to overlay IRM image to verify alignment 
                          (state tracked by variable `irm_cb_var`)
              - `img_split_cb`: Checkbox to display and edit image split location 
                                (state tracked by variable `img_split_cb_var`)
                    - `split_pos_tb`: Textbox to set split position (input stored in `split_pos_input`)
              - `straylit_cb`: Checkbox for seeing straylight detection region 
                               (state tracked by `straylit_cb_var`)
                    - `straylit_thresh_tb`: Textbox for editing intensity thresholds for straylight
                                            detection region(input stored in `straylit_thresh_tb_var`); 
                                            formatted as "left min, max, right min, max intensity"

           - `controls_frame2`: widgets for FOV region detection
              - `fov_thresh_cb`: Checkbox to show FOV mask (state tracked by `fov_thresh_cb_var`)
                    - `fov_thresh_tb`: Textbox to adjust FOV intensity threshold (defaults is 100%)
            
           - `canvas`: Displays the image based on checkbox states

           - `controls_frame3`: Button to proceed to the next window
        """
        self.top_frame=guiutil.create_toplevel_container(parent=self.root2)
        #==========================================================================================
        self.controls_frame1=guiutil.create_frame(parent=self.top_frame)
        self.irm_cb, self.irm_cb_var=guiutil.create_cb(to_function=self.show_image, 
                                                       text="Check alignment: Overlay Average IRM image",
                                                       parent=self.controls_frame1,padx=(0, 70))
        (self.img_split_cb , 
         self.img_split_cb_var)=guiutil.create_cb(to_function=self.show_split_position, 
                                                  text="Check and edit split position",
                                                  parent=self.controls_frame1)
        (self.split_pos_tb,
         self.split_pos_input)=guiutil.create_tb(function_binding=self.update_split_pos_from_tb,
                                                 bound_how="<Return>", 
                                                 init_txt=str(self.split_position), 
                                                 padx=(0,70),parent=self.controls_frame1)
        #. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
        (self.straylit_cb,
         self.straylit_cb_var)=guiutil.create_cb(to_function=self.check_straylight, 
                                                 text="Check auto thresholded region\n for stray light detection",
                                                 parent=self.controls_frame1)
        self.straylit_label=guiutil.create_label(text="Threshold\n intensities:", parent=self.controls_frame1)
        (self.straylit_thresh_tb,
         self.straylit_thresh_tb_var)=guiutil.create_tb(function_binding=self.update_straylight_thresholding_from_tb,
                                                        bound_how="<Return>", 
                                                        init_txt="",width=20,parent=self.controls_frame1)
        self.update_straylit_tb()                          # Initialize straylight intensity textbox
        #==========================================================================================
        self.controls_frame2=guiutil.create_frame(parent=self.top_frame)
        self.fov_thresh_cb , self.fov_thresh_cb_var=guiutil.create_cb(to_function=self.FOV_thresholding, 
                                                                      text="Check and edit autothresholding",
                                                                      parent=self.controls_frame2)
        (self.fov_thresh_tb,
         self.fov_thresh_tb_var)=guiutil.create_tb(function_binding=self.update_FOV_thresholding_from_tb,
                                                   bound_how="<Return>", 
                                                   init_txt=str(self.eff_fov_thresh),
                                                   parent=self.controls_frame2)
        #==========================================================================================
        self.canvas=guiutil.create_canvas(self.top_frame)
        # if canvas is updated, `center_image` function is called to recenter it
        self.canvas.bind("<Configure>", self.center_image)      
        self.show_image()
        #==========================================================================================
        self.controls_frame3=guiutil.create_frame(parent=self.top_frame)
        self.next_button = guiutil.create_button(text="Next >>", 
                                                          to_function=lambda: None,
                                                          side=tk.RIGHT, parent=self.controls_frame3)
        guiutil.create_button(text="?", to_function=hlp.show_help_analyze_window,
                              side=tk.LEFT,  width=1, parent=self.controls_frame3)
        
        guiutil.change_state_of_elements(disable=[self.straylit_thresh_tb,
                                                  self.straylit_label, 
                                                  self.split_pos_tb])
################################################################################################### 

    def show_split_position(self):
        """
        This function is triggered by `img_split_cb` checkbox. When checked, it displays the 
        `avg_bkg_image` with a blue vertical split line at the current split position.
        """
        if self.img_split_cb_var.get():
            guiutil.change_state_of_elements(disable=[self.irm_cb],
                                             enable=[self.split_pos_tb], 
                                             set_false=[self.irm_cb_var])
        else:
            guiutil.change_state_of_elements(enable=[self.irm_cb], 
                                             disable=[self.split_pos_tb])
        self.show_image()                            # updates canvas with image 

    def update_split_pos_from_tb(self,event):
        """
        Triggered by `split_pos_tb` textbox. Updates split position based on its input.
        Recalculates all straylight related calculations based on the new split position.
             - If anything other than integer/float is entered by user,  
               the parameter will revert to its previous value
        """
        self.root2.focus()   # inactivate cursor on textbox
        self.split_position=guiutil.update_vars_from_tb_input(textbox='split', 
                                                              vars_to_update=self.split_position,
                                                              other_inputs=(self.avg_bkg_image, self.split_pos_input))
        self.split_pos_input.set(str(self.split_position))
        self.show_image()  # handles showing the image wiht a blue split line at the split position

        self.autocalculate_straylight();
        self.update_straylit_tb()
        if hasattr(self, "straylight_calc_result"): 
            self.update_straylight_calc_result()
            
        self.FOV_mask=cvutil.otsu_thresholding(self.avg_bkg_image, self.split_position,
                                                eff_thresh=self.eff_fov_thresh)
###################################################################################################

    def check_straylight(self):
        """
        Triggered by `straylit_cb` checkbox. Enables textbox `straylit_thresh_tb` for thresholding 
        straylight detection region and displays label widget with stray light intensity calculation result. 
        Also updates canvas with `avg_bkg_image` overlayed with red mask over straylight detection region.
        """
        if self.straylit_cb_var.get():
            guiutil.change_state_of_elements(disable=[self.irm_cb,self.img_split_cb,self.split_pos_tb],
                                             enable=[self.straylit_thresh_tb, self.straylit_label], 
                                             set_false=[self.irm_cb_var,self.img_split_cb_var])
            if not hasattr(self, "straylight_calc_result"):
                self.straylight_calc_result =guiutil.create_label(parent=self.controls_frame1, side=tk.RIGHT)
            self.update_straylight_calc_result()
        else: 
            guiutil.change_state_of_elements(disable=[self.straylit_thresh_tb,self.straylit_label, 
                                                      self.split_pos_tb, self.straylight_calc_result],
                                             enable=[self.irm_cb,self.img_split_cb]) 
        self.show_image()

    def autocalculate_straylight(self):
        """
        Automatically determines intensity cutoffs values required for thresholding the stray light
        detection region (`left_stray_min`, `left_stray_max`, `right_stray_min`, `right_stray_max`),
        a mask for this region `straylight_overlay`, and thr detected stray light intensity at left
        and right side of the image (`left_stray_light`, `right_stray_light`)
        """
        (self.left_stray_min, self.left_stray_max, 
         self.right_stray_min, self.right_stray_max, 
         self.straylight_overlay,
         self.left_stray_light, self.right_stray_light)=cvutil.return_autosegmented_straylight(self.avg_bkg_image, 
                                                                                                self.split_position)

    def update_straylight_calc_result(self):
        """Updates the `straylight_calc_result` label widget with calculated stray light intensity values."""
        self.straylight_calc_result.config(text=f"Calculated stray light intensity\nLeft: {int(self.left_stray_light)}, Right: {int(self.right_stray_light)}") 
        guiutil.change_state_of_elements(disable=[self.straylight_calc_result])
    
    def update_straylit_tb(self):
        """
        Updates the `straylit_thresh_tb` textbox with left/right min/max intensity threshold values
        for thresholding the straylight detection region.
        """
        self.straylit_thresh_tb_var.set(f"{self.left_stray_min} {self.left_stray_max} {self.right_stray_min} {self.right_stray_max}") # enter here

    def update_straylight_thresholding_from_tb(self,event):
        """
        Triggered when the `straylit_thresh_tb` is edited by user.
        This funciion recalculates stray light intensity related results, and canvas image
             - If anything other than space separated integer/float is entered by user,  
               the parameters will revert to previous value
        """
        self.root2.focus()   # inactivate cursor on textbox
        (self.left_stray_min,self.left_stray_max,
         self.right_stray_min,self.right_stray_max)=guiutil.update_vars_from_tb_input(textbox='straylight', 
                                                                                      other_inputs=self.straylit_thresh_tb_var, 
                                                                                      vars_to_update=(self.left_stray_min,self.left_stray_max,
                                                                                                     self.right_stray_min,self.right_stray_max))     
        self.update_straylit_tb()
        (self.left_stray_light, self.right_stray_light,
         self.straylight_overlay)=cvutil.user_defined_straylight(self.avg_bkg_image,
                                                                  self.split_position,
                                                                  self.left_stray_min,self.left_stray_max,
                                                                  self.right_stray_min,self.right_stray_max)
        self.update_straylight_calc_result(); 
        self.show_image()

###################################################################################################    
    
    def FOV_thresholding(self):
        """
        This function is triggered by `fov_thresh_cb` checkbox. It updates `canvas` with `avg_bkg_image`
        overlayed with `FOV_mask` in red.
        """
        if self.fov_thresh_cb_var.get():
            guiutil.change_state_of_elements(disable=[self.irm_cb, self.img_split_cb, self.split_pos_tb, 
                                                      self.straylit_cb, self.straylit_thresh_tb, 
                                                      self.straylit_label],
                                             enable=[self.fov_thresh_tb],
                                             set_false=[self.irm_cb_var,  self.img_split_cb_var, 
                                                        self.straylit_cb_var])
        else:
            guiutil.change_state_of_elements(enable=[self.irm_cb,self.img_split_cb, 
                                                     self.straylit_cb],
                                             disable=[self.fov_thresh_tb])
        self.show_image()     # displays `avg_bkg_image` overlayed with `FOV_mask`

    def update_FOV_thresholding_from_tb(self,event):
        """
        Triggered by `fov_thresh_tb` textbox edited by user. This function updates 
        `eff_fov_thresh` variable, and recalculates FOV mask and updates the image on `canvas`.
             - If anything other than integer/float is entered, `fov_thresh_tb` and `eff_fov_thresh` 
               will revert to previous value
        """
        self.root2.focus()  # inactivate cursor on textbox
        self.eff_fov_thresh=guiutil.update_vars_from_tb_input(textbox="FOV", 
                                                              vars_to_update=self.eff_fov_thresh, 
                                                              other_inputs=self.fov_thresh_tb_var)
        self.fov_thresh_tb_var.set(str(self.eff_fov_thresh))
        self.FOV_mask=cvutil.otsu_thresholding(self.avg_bkg_image, self.split_position, 
                                                eff_thresh=self.eff_fov_thresh)
        self.show_image()

###################################################################################################
    def show_image(self):
        """
        This fucntion updates the image on `canvas` based on the following checkbox states.
            - if `irm_cb` is checked:  overlays `rep_irm_image` on `avg_bkg_image`
            - if `img_split_cb` is checked: displays a split line on `avg_bkg_image`
            - if `straylit_cb` is checked: stray light detection region is overlayed on `avg_bkg_image`
            - if `fov_thresh_cb` is checked: the FOV masis overlayed on `avg_bkg_image` 
            - else: just displays `avg_bkg_image`
        """
        if self.irm_cb_var.get():
            img=cvutil.display_irm_bkg_overlap_image(self.rep_irm_image,self.avg_bkg_image,
                                                      self.split_position,
                                                      c.left_color, c.right_color )
        elif self.img_split_cb_var.get():
            img=cvutil.display_split_line_on_bkgimage(self.avg_bkg_image,self.split_position,self.max_intensity)
        elif self.straylit_cb_var.get():
            img=cvutil.display_mask_on_bkgimage(self.avg_bkg_image,self.straylight_overlay,self.max_intensity)
        elif self.fov_thresh_cb_var.get():
            img=cvutil.display_mask_on_bkgimage(self.avg_bkg_image,self.FOV_mask,self.max_intensity)
        else:
            img = cv2.cvtColor(self.avg_bkg_image, cv2.COLOR_GRAY2BGR)
        self.tk_image= cvutil.get_formatted_image(img,self.max_intensity,self.min_intensity)
        self.canvas.delete("all")
        self.canvas_image_id = self.canvas.create_image(0, 0, anchor='nw', image=self.tk_image)
        self.center_image()

    def center_image(self, event=None):
        """
        Centers the displayed image within the `canvas` widget. Called automatically when `canvas` is updated.
        """
        self.canvas.coords(self.canvas_image_id,self.canvas.winfo_width() / 2, self.canvas.winfo_height() / 2)
        self.canvas.itemconfig(self.canvas_image_id, anchor='center')
