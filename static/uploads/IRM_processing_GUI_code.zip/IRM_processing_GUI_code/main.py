# importing libraries
import tkinter as tk
from tkinter import ttk
from tkinter import font
import sv_ttk                  # the sun valley ttk theme
import pywinstyles, sys        # For styling the window title bar on Windows

import os, random
import regex as re

import numpy as np
import torch

import PIL, cv2
import matplotlib.pyplot as plt
from matplotlib.figure import Figure
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

import threading, queue

import pickle      # not used#############################################


import utils.gui_utils as guiutil        # utility functions for GUI widget creation and updating
import utils.cv_utils as cvutil          # utility functions for image processing 
import utils.lissajous_utils as lissutil # Utility funcitons for lissajous plot creation and fitting
import utils.constants as c              # Contains constants related to interference microscopy instrumentation
import utils.help_button_content as hlp  # Contains constants that are shown when user clicks help button

from gui.image_viewer import BKGIRMImageviewer                # first window components
from gui.analyze_viewer import AnalysisWindow                 # Second window components
from gui.lissajous_viewer import  LissajousWindow             # Third window components
from gui.heightmap_viewer import  HeightmapWindow             # Fourth window components

class AppState:
    """A simple class to hold and manage the shared state across different application windows."""
    def __init__(self):
        self.avg_bkg_image = None                         # averaged background image
        self.irm_image_files = None                       # List of IRM image file paths
        self.max_intensity_of_bkg = None                  # Maximum intensity of the background
        self.min_intensity_of_bkg = None                  # Minimum intensity of the background
        self.split_position = None                        # The x-coordinate for splitting images
        self.FOV_mask =None                               # Mask for the field of view
        self.left_stray_light = None                      # Calculated stray light for the left side
        self.right_stray_light = None                     # stray light for the right side
        self.roi_points=None                              # Selected ROI points for lissajous plotting
        self.shift_by=None                                # Affine transformation matrix used to align the right half of images.
        self.x= None                                      # fit parameter
        self.fit_params=None                              # fit parameters
    
class MainApplication:
    """The main application class that controls display of the windows, and navigation to the next window."""
    def __init__(self, master, appstate):
        self.master = master
        self.appstate=appstate
        master.title("IRM Processing App")
        master.state('zoomed')      # open in fullscreen mode
        self.show_bkg_irm_viewers() # show the first window

    def show_bkg_irm_viewers(self):
        """first window: 
         - clear window content, and create new container frame, 
         - use `BKGIRMImageviewer` class to add widget and their functionality
         - next button is linked to `show_analysis_window` function (second window)"""
        guiutil.clear_window_content(self.master)                                    
        imageviewer_frame=guiutil.create_toplevel_container(self.master)              
        self.imageviewer_window = BKGIRMImageviewer(imageviewer_frame)
        self.imageviewer_window.next_button.config(command=self.show_analysis_window)

    def show_analysis_window(self):
        """Second window: 
         - update appstate with variables that needs to be retained across windows
         - clear window content, and create new container frame, 
         - use `AnalysisWindow` class to add widget and their functionality
         - next button is linked to `show_lissajous_window` function (third window)"""
        self.appstate.avg_bkg_image = self.imageviewer_window.bkg_viewer.avg_image
        self.appstate.irm_image_files = self.imageviewer_window.irm_viewer.image_files
        self.appstate.max_intensity_of_bkg = self.imageviewer_window.bkg_viewer.max_intensity_of_bkg; 
        self.appstate.min_intensity_of_bkg = self.imageviewer_window.bkg_viewer.min_intensity_of_bkg;

        guiutil.clear_window_content(self.master)
        analysis_frame=guiutil.create_toplevel_container(self.master)
        self.analysis_window = AnalysisWindow(analysis_frame, self.appstate)
        self.analysis_window.next_button.config(command=self.show_lissajous_window) 

    def show_lissajous_window(self):
        """Third window: 
         - update appstate with variables that needs to be retained across windows
         - clear window content, and create new container frame, 
         - use `LissajousWindow` class to add widget and their functionality
         - next button is linked to `show_height_map_window` function (Fourth window)"""
        self.appstate.split_position = self.analysis_window.split_position
        self.appstate.FOV_mask = self.analysis_window.FOV_mask
        self.appstate.left_stray_light = self.analysis_window.left_stray_light
        self.appstate.right_stray_light = self.analysis_window.right_stray_light

        guiutil.clear_window_content(self.master)
        lissajous_frame=guiutil.create_toplevel_container(self.master)
        self.lissajous_window = LissajousWindow(lissajous_frame, appstate)
        self.lissajous_window.next_button.config(command=self.show_height_map_window) 
    
    def show_height_map_window(self):
        """Fourth (final) window: 
         - update appstate with variables that needs to be retained across windows
         - clear window content, and create new container frame, 
         - use `HeightMapWindow` class to add widget and their functionality"""
                
        self.appstate.roi_points=self.lissajous_window.roi_points
        self.appstate.shift_by=self.lissajous_window.shift_by;
        self.appstate.x= self.lissajous_window.x
        self.appstate.fit_params=self.lissajous_window.fit_params

        
        data = (self.appstate.avg_bkg_image, self.appstate.irm_image_files, self.appstate.max_intensity_of_bkg,
                self.appstate.min_intensity_of_bkg,self.appstate.split_position,self.appstate.FOV_mask,
                self.appstate.left_stray_light,self.appstate.right_stray_light, self.appstate.roi_points,                 
                self.appstate.shift_by,self.appstate.x,self.appstate.fit_params)                              # fit parameters)
        with open("data.pkl", "wb") as f:
            pickle.dump(data, f)



        guiutil.clear_window_content(self.master)
        heightmap_frame=guiutil.create_toplevel_container(self.master)
        self.heightmap_window = HeightmapWindow(heightmap_frame, appstate)
        self.heightmap_window.close_button.config(command=lambda:None)#guiutil.clear_window_content(self.master))


if __name__ == "__main__":
    root = tk.Tk()
    appstate=AppState()                        #to hold and manage the shared state across different application windows
    app = MainApplication(root, appstate)      # starts main application
    sv_ttk.set_theme("dark")                   # dark theme applied to gui
    guiutil.apply_dark_theme_to_titlebar(root)      
    guiutil.apply_fontstyle(root, c.fontfamily, c.fontsize ) # font style applied to all gui elements
    root.mainloop()                            # main event loop




